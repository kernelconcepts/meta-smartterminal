#!/bin/sh

if [ "$#" -ne 2 ]
then
  echo "invalid number of arguments"
  exit 1
fi

base64 -d $1 > $2
