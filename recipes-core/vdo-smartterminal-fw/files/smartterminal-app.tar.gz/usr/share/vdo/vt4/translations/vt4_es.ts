<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>ActivityMeta</name>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="33"/>
        <source>Rest</source>
        <translation type="unfinished">Descanso</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="34"/>
        <source>Available</source>
        <translation type="unfinished">Disponible</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="35"/>
        <source>Work</source>
        <translation type="unfinished">Trabajo</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="36"/>
        <source>Driving</source>
        <translation type="unfinished">Conducción</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="37"/>
        <source>Unknown</source>
        <translation type="unfinished">Desconocido</translation>
    </message>
</context>
<context>
    <name>AdminPassword</name>
    <message>
        <location filename="../qml/content/settings/AdminPassword.qml" line="10"/>
        <source>ADMINISTRATION AREA</source>
        <translation>ÁREA DE ADMINISTRACIÓN</translation>
    </message>
</context>
<context>
    <name>BroadcastAddress</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/BroadcastAddress.qml" line="6"/>
        <source>BROADCAST ADDRESS</source>
        <translation>DIRECCIÓN DE EMISIÓN</translation>
    </message>
</context>
<context>
    <name>Dataport</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/Dataport.qml" line="10"/>
        <source>DATAPORT</source>
        <translation>PUERTO DE DATOS</translation>
    </message>
</context>
<context>
    <name>Date</name>
    <message>
        <location filename="../qml/content/settings/datetime/Date.qml" line="10"/>
        <source>DATE</source>
        <translation>FECHA</translation>
    </message>
</context>
<context>
    <name>DateTime</name>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="9"/>
        <source>disabled</source>
        <translation type="unfinished">desactivado</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="45"/>
        <source>NTP Server</source>
        <translation>Servidor NTP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="51"/>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="57"/>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="63"/>
        <source>Time Zone</source>
        <translation>Zona horaria</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="69"/>
        <source>Daylight Saving Time</source>
        <translation>Hora de ahorro energético</translation>
    </message>
</context>
<context>
    <name>DemoEvent</name>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="11"/>
        <source>DETAILS</source>
        <translation>DETALLES</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="53"/>
        <source>License Plate:</source>
        <translation>Matrícula:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="85"/>
        <source>From:</source>
        <extracomment>Timespan</extracomment>
        <translation>De:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="117"/>
        <source>Till:</source>
        <extracomment>Timespan</extracomment>
        <translation>Hasta:</translation>
    </message>
</context>
<context>
    <name>DownloadCardLabel</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="19"/>
        <source>DRIVERCARD DOWNLOAD</source>
        <translation>DESCARGAR TARJETA DE CONDUCTOR</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="26"/>
        <source>WORKSHOPCARD DOWNLOAD</source>
        <translation>DESCARGAR TARJETA DE TALLER</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="33"/>
        <source>COMPANYCARD DOWNLOAD</source>
        <translation>DESCARGAR TARJETA DE EMPRESA</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="40"/>
        <source>KEY DOWNLOAD</source>
        <translation type="unfinished">DESCARGA DE LA CLAVE</translation>
    </message>
</context>
<context>
    <name>DownloadError</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="44"/>
        <source>CARD READ OR DOWNLOAD ERROR&lt;br&gt;Please check card orientation. Chip facing away from you.</source>
        <translation>ERROR DE DESCARGA O LECTURA DE TARJETA&lt;br&gt;Comprueba la orientación de la tarjeta. El chip debe estar en la dirección opuesta a ti.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="60"/>
        <source>Invalid Card</source>
        <translation type="unfinished">Tarjeta no válida</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="79"/>
        <source>DOWNLOAD KEY READ OR DOWNLOAD ERROR.</source>
        <translation type="unfinished">ERROR DE LECTURA DE CLAVE DE DESCARGA O ERROR DE DESCARGA.</translation>
    </message>
    <message>
        <source>CARD REMOVED TOO EARLY</source>
        <translation type="vanished">TARJETA RETIRADA DEMASIADO PRONTO</translation>
    </message>
    <message>
        <source>INSERTED INVALID CARD</source>
        <translation type="vanished">TARJETA NO VÁLIDA INSERTADA</translation>
    </message>
    <message>
        <source>INVALID RFID TAG</source>
        <translation type="vanished">ETIQUETA RFID NO VÁLIDA</translation>
    </message>
    <message>
        <source>RFID TAG READ ERROR</source>
        <translation type="vanished">ERROR DE LECTURA DE ETIQUETA RFID</translation>
    </message>
</context>
<context>
    <name>DownloadFrame</name>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="102"/>
        <source>PLEASE SCAN DRIVER LICENSE!</source>
        <translation>¡ESCANEA EL PERMISO DE CONDUCIR!</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="125"/>
        <source>PROCEED WITHOUT LICENSE SCAN</source>
        <translation>PROCEDER SIN EL ESCANEADO DEL PERMISO</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="163"/>
        <source>OPEN DOWNLOAD KEY MENU</source>
        <translation type="unfinished">ABRIR MENÚ DE CLAVE DE DESCARGA</translation>
    </message>
</context>
<context>
    <name>DownloadFrameSmall</name>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="168"/>
        <source>PLEASE SCAN DRIVER LICENSE!</source>
        <translation>¡ESCANEA EL PERMISO DE CONDUCIR!</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="201"/>
        <source>PROCEED WITHOUT LICENSE SCAN</source>
        <translation>PROCEDER SIN EL ESCANEADO DEL PERMISO</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="239"/>
        <source>OPEN DOWNLOAD KEY MENU</source>
        <translation type="unfinished">ABRIR MENÚ DE CLAVE DE DESCARGA</translation>
    </message>
</context>
<context>
    <name>DownloadRfid</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="38"/>
        <source>VALID RFID TAG FOUND!</source>
        <translation>¡ETIQUETA RFID VÁLIDA ENCONTRADA!</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="54"/>
        <source>FOUND RFID TAG. READING, PLEASE WAIT.</source>
        <translation>ETIQUETA RFID ENCONTRADA. LEYENDO, ESPERA.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="61"/>
        <source>READING VALID RFID TAG DONE.</source>
        <translation>LECTURA VÁLIDA DE LA ETIQUETA RFID REALIZADA.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="68"/>
        <source>AN ERROR OCCURED WHILE READING RFID TAG.</source>
        <translation type="unfinished">SE HA PRODUCIDO UN ERROR AL LEER LA ETIQUETA RFID.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="79"/>
        <source>FOUND INVALID RFID TAG.</source>
        <translation type="unfinished">SE HA ENCONTRADO UNA ETIQUETA RFID NO VÁLIDA.</translation>
    </message>
</context>
<context>
    <name>DrivenVehicles</name>
    <message>
        <location filename="../qml/content/driveroverview/DrivenVehicles.qml" line="60"/>
        <source>from</source>
        <extracomment>Timespan</extracomment>
        <translation>De</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DrivenVehicles.qml" line="60"/>
        <source>till</source>
        <translation>hasta</translation>
    </message>
</context>
<context>
    <name>DriverInformation</name>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="13"/>
        <source>Last Download</source>
        <translation>Última descarga</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="18"/>
        <source>Next Download</source>
        <translation>Próxima descarga</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="23"/>
        <source>Next Break</source>
        <translation>Siguiente descanso</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="27"/>
        <source>Remaining Driving Time (Daily)</source>
        <translation>Tiempo de conducción restante (diario)</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="31"/>
        <source>Remaining Driving Time (Week)</source>
        <translation>Tiempo de conducción restante (semanal)</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="36"/>
        <source>Remaining extended driving time</source>
        <translation>Tiempo de conducción extendido restante</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="41"/>
        <source>Remaining reduced daily rest time</source>
        <translation>Tiempo de descanso reducido diariamente restante</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="46"/>
        <source>Sum break time</source>
        <translation>Añadir tiempo de descanso</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="51"/>
        <source>Sum driving time</source>
        <translation>Añadir tiempo de conducción</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="56"/>
        <source>Sum working time</source>
        <translation>Añadir tiempo de trabajo</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="61"/>
        <source>Last activity</source>
        <translation>Última actividad</translation>
    </message>
</context>
<context>
    <name>DriverOverview</name>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="8"/>
        <source>DRIVER INFORMATION</source>
        <translation>INFORMACIÓN DEL CONDUCTOR</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="13"/>
        <source>DRIVEN VEHICLES</source>
        <translation>VEHÍCULOS CONDUCIDOS</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="19"/>
        <source>EVENTS</source>
        <translation>EVENTOS</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="25"/>
        <source>CALENDAR</source>
        <translation>CALENDARIO</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="31"/>
        <source>INFORMATION</source>
        <translation>INFORMACIÓN</translation>
    </message>
</context>
<context>
    <name>ErrorConfiguration</name>
    <message>
        <location filename="../qml/content/errors/ErrorConfiguration.qml" line="6"/>
        <source>Configuration incomplete! System not functional!</source>
        <translation>¡Configuración incompleta! ¡El sistema no es funcional!</translation>
    </message>
</context>
<context>
    <name>ErrorFrame</name>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="17"/>
        <source>HOME</source>
        <translation type="unfinished">INICIO</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="22"/>
        <source>Proceed with factory reset?</source>
        <translation type="unfinished">¿Proceder con el reseteo completo de los valores?</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="29"/>
        <source>Proceed with system update?</source>
        <translation type="unfinished">¿Proceder con la actualización del sistema?</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="36"/>
        <source>Transfer of system update to device in progress</source>
        <translation type="unfinished">Transferencia de la actualización del sistema al dispositivo en curso</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="44"/>
        <source>Installation of system update in progress</source>
        <translation type="unfinished">Instalación de la actualización del sistema en curso</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="52"/>
        <source>An error occured during update!</source>
        <translation type="unfinished">Se ha producido un error durante la actualización.</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="60"/>
        <source>USB Operation</source>
        <translation type="unfinished">Funcionamiento del USB</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="73"/>
        <source>Your changes have been applied</source>
        <translation type="unfinished">Los cambios se han realizado</translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="103"/>
        <source>System is going to reboot</source>
        <translation type="unfinished">El sistema se va a reiniciar</translation>
    </message>
</context>
<context>
    <name>ErrorMessages</name>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="24"/>
        <source>Unknown System Failure</source>
        <translation type="unfinished">Fallo de sistema desconocido</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="25"/>
        <source>Logging Facility Failure</source>
        <translation type="unfinished">Fallo de la función de registro</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="26"/>
        <source>Smartcard Reader Failure</source>
        <translation type="unfinished">Fallo del lector de tarjetas inteligentes</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="27"/>
        <source>Touchscreen Detection Failure</source>
        <translation type="unfinished">Fallo de detección de la pantalla táctil</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="28"/>
        <source>Rfid Reader Failure</source>
        <translation type="unfinished">Fallo del lector Rfid</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="30"/>
        <source>Encryption Key Failure</source>
        <translation type="unfinished">Fallo de la clave de encriptación</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="32"/>
        <source>One or more files are corrupted</source>
        <translation type="unfinished">Uno o más archivos están dañados</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="29"/>
        <source>Configuration Failure</source>
        <translation type="unfinished">Fallo de configuración</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="31"/>
        <source>Serial Number Failure</source>
        <translation type="unfinished">Fallo del número de serie</translation>
    </message>
</context>
<context>
    <name>ErrorMultipleDataCarrier</name>
    <message>
        <location filename="../qml/content/errors/ErrorMultipleDataCarrier.qml" line="6"/>
        <source>Multiple Data Carrier Error</source>
        <translation>Error del portador de datos múltiples</translation>
    </message>
</context>
<context>
    <name>ErrorNTP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNTP.qml" line="6"/>
        <source>NTP Error</source>
        <translation>Error NTP</translation>
    </message>
</context>
<context>
    <name>ErrorNetworkDHCP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkDHCP.qml" line="6"/>
        <source>DHCP Error</source>
        <translation>Error DHCP</translation>
    </message>
</context>
<context>
    <name>ErrorNetworkIP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkIP.qml" line="6"/>
        <source>Network IP Error</source>
        <translation>Error de PI de red</translation>
    </message>
</context>
<context>
    <name>ErrorNetworkWiFi</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkWiFi.qml" line="6"/>
        <source>WiFi Error</source>
        <translation>Error de WiFi</translation>
    </message>
</context>
<context>
    <name>ErrorRFID</name>
    <message>
        <location filename="../qml/content/errors/ErrorRFID.qml" line="6"/>
        <source>RFID Error</source>
        <translation>Error RFID</translation>
    </message>
</context>
<context>
    <name>ErrorSCard</name>
    <message>
        <location filename="../qml/content/errors/ErrorSCard.qml" line="6"/>
        <source>SmartCard Error. Please check card orientation. Chip facing away from you.</source>
        <translation>Error de SmartCard. Comprueba la orientación de la tarjeta. El chip debe estar en la dirección opuesta a ti.</translation>
    </message>
</context>
<context>
    <name>ErrorSaveSettings</name>
    <message>
        <location filename="../qml/content/errors/ErrorSaveSettings.qml" line="6"/>
        <source>Save Settings Error</source>
        <translation>Error al guardar las configuraciones</translation>
    </message>
</context>
<context>
    <name>ErrorTime</name>
    <message>
        <location filename="../qml/content/errors/ErrorTime.qml" line="6"/>
        <source>Manual Time Set Error</source>
        <translation>Error de configuración manual de la hora</translation>
    </message>
</context>
<context>
    <name>ErrorUSBKey</name>
    <message>
        <location filename="../qml/content/errors/ErrorUSBKey.qml" line="6"/>
        <source>USB Key Error</source>
        <translation>Error de llave USB</translation>
    </message>
</context>
<context>
    <name>EventDetails</name>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="12"/>
        <source>DETAILS</source>
        <translation type="unfinished">DETALLES</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="58"/>
        <source>License Plate:</source>
        <translation type="unfinished">Matrícula:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="90"/>
        <source>From:</source>
        <extracomment>Timespan</extracomment>
        <translation type="unfinished">De:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="133"/>
        <source>Till:</source>
        <extracomment>Timespan</extracomment>
        <translation type="unfinished">Hasta:</translation>
    </message>
</context>
<context>
    <name>EventMessages</name>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="97"/>
        <source>No further details</source>
        <translation type="unfinished">No hay más detalles</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="98"/>
        <source>Insertion of non-valid card</source>
        <translation>Inserción de tarjeta no válida</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="99"/>
        <source>Card conflict</source>
        <translation>Conflicto de tarjetas</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="100"/>
        <source>Time overlap</source>
        <translation>Superposición de hora</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="101"/>
        <source>Driving without an appropriate card</source>
        <translation>Conducción sin tarjeta adecuada</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="102"/>
        <source>Card insertion while driving</source>
        <translation>Inserción de la tarjeta al conducir</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="103"/>
        <source>Last card session not correctly closed</source>
        <translation>La última sesión de la tarjeta no se ha cerrado correctamente</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="104"/>
        <source>Over speeding</source>
        <translation>Velocidad excesiva</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="105"/>
        <source>Power supply interruption</source>
        <translation>Interrupción de la alimentación</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="109"/>
        <source>Communication error with the remote communication facility</source>
        <translation>Error de comunicación con el complejo de comunicaciones remoto</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="110"/>
        <source>Absence of position information from GNSS receiver</source>
        <translation>Ausencia de información de posición del receptor GNSS</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="111"/>
        <source>Communication error with the external GNSS facility</source>
        <translation>Error de comunicación con el complejo GNSS externo</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="113"/>
        <source>Motion sensor authentication failure</source>
        <translation type="unfinished">Fallo de autentificación del sensor de movimiento</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="114"/>
        <source>Tachograph card authentication failure</source>
        <translation type="unfinished">Fallo de autentificación de la tarjeta del tacógrafo</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="115"/>
        <source>Unauthorised change of motion sensor</source>
        <translation type="unfinished">Cambio no autorizado del sensor de movimiento</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="116"/>
        <source>Card data input integrity error</source>
        <translation type="unfinished">Error de integridad de los datos de la tarjeta</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="117"/>
        <source>Stored user data integrity error</source>
        <translation type="unfinished">Error de integridad de los datos del usuario almacenados</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="118"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="127"/>
        <source>Internal data transfer error</source>
        <translation type="unfinished">Error interno de transferencia de datos</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="119"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="128"/>
        <source>Unauthorised case opening</source>
        <translation type="unfinished">Apertura de carcasa no autorizada</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="120"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="129"/>
        <source>Hardware sabotage</source>
        <translation type="unfinished">Sabotaje del hardware</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="121"/>
        <source>Tamper detection of GNSS</source>
        <translation type="unfinished">Detección de alteraciones en el sistema GNSS</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="122"/>
        <source>External GNSS facility authentication failure</source>
        <translation type="unfinished">Fallo de autentificación de la unidad GNSS externa</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="123"/>
        <source>External GNSS facility certificate expired</source>
        <translation type="unfinished">El certificado de la unidad GNSS externa ha expirado.</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="125"/>
        <source>Authentication failure</source>
        <translation type="unfinished">Fallo de autentificación</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="126"/>
        <source>Stored data integrity error</source>
        <translation type="unfinished">Error de integridad de los datos almacenados</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="131"/>
        <source>VU internal fault</source>
        <translation type="unfinished">Fallo interno de la VU</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="132"/>
        <source>Printer fault</source>
        <translation type="unfinished">Fallo de la impresora</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="133"/>
        <source>Display fault</source>
        <translation type="unfinished">Fallo en la pantalla</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="134"/>
        <source>Downloading fault</source>
        <translation type="unfinished">Fallo de descarga</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="135"/>
        <source>Sensor fault</source>
        <translation type="unfinished">Fallo del sensor</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="136"/>
        <source>Internal GNSS receiver</source>
        <translation type="unfinished">Receptor GNSS interno</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="137"/>
        <source>External GNSS facility</source>
        <translation type="unfinished">Dispositivo GNSS externo</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="138"/>
        <source>Remote communication facility</source>
        <translation type="unfinished">Dispositivo de comunicación a distancia</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="139"/>
        <source>ITS interface</source>
        <translation type="unfinished">Interfaz ITS</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="106"/>
        <source>Motion data error</source>
        <translation>Error de datos de movimiento</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="107"/>
        <source>Vehicle motion conflict</source>
        <translation>Conflicto con el movimiento del vehículo</translation>
    </message>
    <message>
        <source>Security breach attempt</source>
        <translation type="vanished">Intento de rotura de seguridad</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="108"/>
        <source>Time conflict</source>
        <translation>Conflicto de horas</translation>
    </message>
    <message>
        <source>Card</source>
        <translation type="vanished">Tarjeta</translation>
    </message>
    <message>
        <source>Recording equipment</source>
        <translation type="vanished">Equipo de grabación</translation>
    </message>
</context>
<context>
    <name>EventsOfDayList</name>
    <message>
        <location filename="../qml/content/driveroverview/calendar/EventsOfDayList.qml" line="13"/>
        <source>DETAILS</source>
        <translation>DETALLES</translation>
    </message>
    <message>
        <source>Work</source>
        <translation type="vanished">Trabajo</translation>
    </message>
    <message>
        <source>Driving</source>
        <translation type="vanished">Conducción</translation>
    </message>
    <message>
        <source>Available</source>
        <translation type="vanished">Disponible</translation>
    </message>
</context>
<context>
    <name>Gateway</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/Gateway.qml" line="6"/>
        <source>DEFAULT GATEWAY</source>
        <translation>PASARELA PREDETERMINADA</translation>
    </message>
</context>
<context>
    <name>Homescreen</name>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="12"/>
        <source>HOME</source>
        <translation>INICIO</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="18"/>
        <source>Proceed with factory reset?</source>
        <translation type="unfinished">¿Proceder con el reseteo completo de los valores?</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="25"/>
        <source>Proceed with system update?</source>
        <translation type="unfinished">¿Proceder con la actualización del sistema?</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="32"/>
        <source>Transfer of system update to device in progress</source>
        <translation type="unfinished">Transferencia de la actualización del sistema al dispositivo en curso</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="40"/>
        <source>Installation of system update in progress</source>
        <translation type="unfinished">Instalación de la actualización del sistema en curso</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="48"/>
        <source>An error occured during update!</source>
        <translation type="unfinished">Se ha producido un error durante la actualización.</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="97"/>
        <source>USB Operation</source>
        <translation type="unfinished">Funcionamiento del USB</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="104"/>
        <source>Your changes have been applied</source>
        <translation type="unfinished">Los cambios se han realizado</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="110"/>
        <source>System is going to reboot</source>
        <translation type="unfinished">El sistema se va a reiniciar</translation>
    </message>
</context>
<context>
    <name>InfoLocalConfiguration</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoLocalConfiguration.qml" line="6"/>
        <source>Local Configuration Pending</source>
        <translation>Configuración local pendiente</translation>
    </message>
</context>
<context>
    <name>InfoRemoteAccess</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoRemoteAccess.qml" line="6"/>
        <source>Remote Access</source>
        <translation>Acceso remoto</translation>
    </message>
</context>
<context>
    <name>InfoUpdatePending</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoUpdatePending.qml" line="6"/>
        <source>Update Pending</source>
        <translation>Actualización pendiente</translation>
    </message>
</context>
<context>
    <name>IpAddress</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/IpAddress.qml" line="6"/>
        <source>IP ADDRESS</source>
        <translation>DIRECCIÓN IP</translation>
    </message>
</context>
<context>
    <name>Keyboard</name>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="44"/>
        <source>q</source>
        <extracomment>Keyboard normal Key Q</extracomment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="105"/>
        <source>=/&lt;</source>
        <translation type="unfinished">=/&lt;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="143"/>
        <source>Q</source>
        <extracomment>Keyboard capsLock Key Q</extracomment>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="180"/>
        <source>@</source>
        <extracomment>Keyboard special Key Q</extracomment>
        <translation type="unfinished">@</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="181"/>
        <source>#</source>
        <extracomment>Keyboard special Key W</extracomment>
        <translation type="unfinished">#</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="182"/>
        <source>€</source>
        <extracomment>Keyboard special Key E</extracomment>
        <translation type="unfinished">€</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="183"/>
        <source>$</source>
        <extracomment>Keyboard special Key R</extracomment>
        <translation type="unfinished">$</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="184"/>
        <source>&amp;</source>
        <extracomment>Keyboard special Key T</extracomment>
        <translation type="unfinished">&amp;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="186"/>
        <source>+</source>
        <extracomment>Keyboard special Key U</extracomment>
        <translation type="unfinished">+</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="187"/>
        <source>*</source>
        <extracomment>Keyboard special Key I</extracomment>
        <translation type="unfinished">*</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="188"/>
        <source>/</source>
        <extracomment>Keyboard special Key O</extracomment>
        <translation type="unfinished">/</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="189"/>
        <source>=</source>
        <extracomment>Keyboard special Key P</extracomment>
        <translation type="unfinished">=</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="191"/>
        <source>%</source>
        <extracomment>Keyboard special Key A</extracomment>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="192"/>
        <source>&quot;</source>
        <extracomment>Keyboard special Key S</extracomment>
        <translation type="unfinished">&quot;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="193"/>
        <source>&apos;</source>
        <extracomment>Keyboard special Key D</extracomment>
        <translation type="unfinished">&apos;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="194"/>
        <source>:</source>
        <extracomment>Keyboard special Key F</extracomment>
        <translation type="unfinished">:</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="195"/>
        <source>;</source>
        <extracomment>Keyboard special Key G</extracomment>
        <translation type="unfinished">;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="196"/>
        <source>!</source>
        <extracomment>Keyboard special Key H</extracomment>
        <translation type="unfinished">!</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="197"/>
        <source>?</source>
        <extracomment>Keyboard special Key J</extracomment>
        <translation type="unfinished">?</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="198"/>
        <source>~</source>
        <extracomment>Keyboard special Key K</extracomment>
        <translation type="unfinished">~</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="199"/>
        <source>|</source>
        <extracomment>Keyboard special Key L</extracomment>
        <translation type="unfinished">|</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="200"/>
        <source>§</source>
        <extracomment>Keyboard special Key Ü</extracomment>
        <translation type="unfinished">§</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="202"/>
        <source>(</source>
        <extracomment>Keyboard special Key Y</extracomment>
        <translation type="unfinished">(</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="203"/>
        <source>)</source>
        <extracomment>Keyboard special Key X</extracomment>
        <translation type="unfinished">)</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="204"/>
        <source>{</source>
        <extracomment>Keyboard special Key C</extracomment>
        <translation type="unfinished">{</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="205"/>
        <source>}</source>
        <extracomment>Keyboard special Key V</extracomment>
        <translation type="unfinished">}</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="206"/>
        <source>[</source>
        <extracomment>Keyboard special Key B</extracomment>
        <translation type="unfinished">[</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="207"/>
        <source>]</source>
        <extracomment>Keyboard special Key N</extracomment>
        <translation type="unfinished">]</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="208"/>
        <source>&lt;</source>
        <extracomment>Keyboard special Key M</extracomment>
        <translation type="unfinished">&lt;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="209"/>
        <source>&gt;</source>
        <extracomment>Keyboard special Key Ö</extracomment>
        <translation type="unfinished">&gt;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="210"/>
        <source>,</source>
        <extracomment>Keyboard special Key Ä</extracomment>
        <translation type="unfinished">,</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="211"/>
        <source>.</source>
        <extracomment>Keyboard special Key -</extracomment>
        <translation type="unfinished">.</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="45"/>
        <source>w</source>
        <extracomment>Keyboard normal Key W</extracomment>
        <translation>w</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="144"/>
        <source>W</source>
        <extracomment>Keyboard capsLock Key W</extracomment>
        <translation>W</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="46"/>
        <source>e</source>
        <extracomment>Keyboard normal Key E</extracomment>
        <translation>e</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="145"/>
        <source>E</source>
        <extracomment>Keyboard capsLock Key E</extracomment>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="47"/>
        <source>r</source>
        <extracomment>Keyboard normal Key R</extracomment>
        <translation>r</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="146"/>
        <source>R</source>
        <extracomment>Keyboard capsLock Key R</extracomment>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="48"/>
        <source>t</source>
        <extracomment>Keyboard normal Key T</extracomment>
        <translation>t</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="147"/>
        <source>T</source>
        <extracomment>Keyboard capsLock Key T</extracomment>
        <translation>T</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="49"/>
        <source>z</source>
        <extracomment>Keyboard normal Key Z</extracomment>
        <translation>z</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="148"/>
        <source>Z</source>
        <extracomment>Keyboard capsLock Key Z</extracomment>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="50"/>
        <source>u</source>
        <extracomment>Keyboard normal Key U</extracomment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="149"/>
        <source>U</source>
        <extracomment>Keyboard capsLock Key U</extracomment>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="51"/>
        <source>i</source>
        <extracomment>Keyboard normal Key I</extracomment>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="150"/>
        <source>I</source>
        <extracomment>Keyboard capsLock Key I</extracomment>
        <translation>I</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="52"/>
        <source>o</source>
        <extracomment>Keyboard normal Key O</extracomment>
        <translation>o</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="151"/>
        <source>O</source>
        <extracomment>Keyboard capsLock Key O</extracomment>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="53"/>
        <source>p</source>
        <extracomment>Keyboard normal Key P</extracomment>
        <translation>p</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="152"/>
        <source>P</source>
        <extracomment>Keyboard capsLock Key P</extracomment>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="55"/>
        <source>a</source>
        <extracomment>Keyboard normal Key A</extracomment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="154"/>
        <source>A</source>
        <extracomment>Keyboard capsLock Key A</extracomment>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="56"/>
        <source>s</source>
        <extracomment>Keyboard normal Key S</extracomment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="155"/>
        <source>S</source>
        <extracomment>Keyboard capsLock Key S</extracomment>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="57"/>
        <source>d</source>
        <extracomment>Keyboard normal Key D</extracomment>
        <translation>d</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="156"/>
        <source>D</source>
        <extracomment>Keyboard capsLock Key D</extracomment>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="58"/>
        <source>f</source>
        <extracomment>Keyboard normal Key F</extracomment>
        <translation>f</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="157"/>
        <source>F</source>
        <extracomment>Keyboard capsLock Key F</extracomment>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="59"/>
        <source>g</source>
        <extracomment>Keyboard normal Key G</extracomment>
        <translation>g</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="158"/>
        <source>G</source>
        <extracomment>Keyboard capsLock Key G</extracomment>
        <translation>G</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="60"/>
        <source>h</source>
        <extracomment>Keyboard normal Key H</extracomment>
        <translation>h</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="159"/>
        <source>H</source>
        <extracomment>Keyboard capsLock Key H</extracomment>
        <translation>H</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="61"/>
        <source>j</source>
        <extracomment>Keyboard normal Key J</extracomment>
        <translation>j</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="160"/>
        <source>J</source>
        <extracomment>Keyboard capsLock Key J</extracomment>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="62"/>
        <source>k</source>
        <extracomment>Keyboard normal Key K</extracomment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="161"/>
        <source>K</source>
        <extracomment>Keyboard capsLock Key K</extracomment>
        <translation>K</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="63"/>
        <source>l</source>
        <extracomment>Keyboard normal Key L</extracomment>
        <translation>l</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="162"/>
        <source>L</source>
        <extracomment>Keyboard capsLock Key L</extracomment>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="64"/>
        <source>ü</source>
        <extracomment>Keyboard normal Key Ü</extracomment>
        <translation>ü</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="163"/>
        <source>Ü</source>
        <extracomment>Keyboard capsLock Key Ü</extracomment>
        <translation>Ü</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="66"/>
        <source>y</source>
        <extracomment>Keyboard normal Key Y</extracomment>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="165"/>
        <source>Y</source>
        <extracomment>Keyboard capsLock Key Y</extracomment>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="67"/>
        <source>x</source>
        <extracomment>Keyboard normal Key X</extracomment>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="166"/>
        <source>X</source>
        <extracomment>Keyboard capsLock Key X</extracomment>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="68"/>
        <source>c</source>
        <extracomment>Keyboard normal Key C</extracomment>
        <translation>c</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="167"/>
        <source>C</source>
        <extracomment>Keyboard capsLock Key C</extracomment>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="69"/>
        <source>v</source>
        <extracomment>Keyboard normal Key V</extracomment>
        <translation>v</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="168"/>
        <source>V</source>
        <extracomment>Keyboard capsLock Key V</extracomment>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="70"/>
        <source>b</source>
        <extracomment>Keyboard normal Key B</extracomment>
        <translation>b</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="169"/>
        <source>B</source>
        <extracomment>Keyboard capsLock Key B</extracomment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="71"/>
        <source>n</source>
        <extracomment>Keyboard normal Key N</extracomment>
        <translation>n</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="170"/>
        <source>N</source>
        <extracomment>Keyboard capsLock Key N</extracomment>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="72"/>
        <source>m</source>
        <extracomment>Keyboard normal Key M</extracomment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="171"/>
        <source>M</source>
        <extracomment>Keyboard capsLock Key M</extracomment>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="73"/>
        <source>ö</source>
        <extracomment>Keyboard normal Key Ö</extracomment>
        <translation>ö</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="172"/>
        <source>Ö</source>
        <extracomment>Keyboard capsLock Key Ö</extracomment>
        <translation>Ö</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="74"/>
        <source>ä</source>
        <extracomment>Keyboard normal Key Ä</extracomment>
        <translation>ä</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="173"/>
        <source>Ä</source>
        <extracomment>Keyboard capsLock Key Ä</extracomment>
        <translation>Ä</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="75"/>
        <location filename="../qml/components/misc/Keyboard.qml" line="185"/>
        <source>-</source>
        <extracomment>Keyboard normal Key -
----------
Keyboard special Key Z</extracomment>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="174"/>
        <source>_</source>
        <extracomment>Keyboard capsLock Key -</extracomment>
        <translation>_</translation>
    </message>
    <message>
        <source>/+=</source>
        <extracomment>Keyboard Button</extracomment>
        <translation type="vanished">/+=</translation>
    </message>
</context>
<context>
    <name>Licence</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="6"/>
        <source>LICENCES</source>
        <translation type="unfinished">LICENCIAS</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="13"/>
        <source>Package List</source>
        <translation type="unfinished">Lista de paquetes</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="20"/>
        <source>More Information</source>
        <translation type="unfinished">Más información</translation>
    </message>
</context>
<context>
    <name>MainFooter</name>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="127"/>
        <source>Your changes have been applied</source>
        <translation type="unfinished">Los cambios se han realizado</translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="162"/>
        <source>Reboot pending for changes to take effect</source>
        <translation type="unfinished">Pendiente de reinicio para que los cambios surtan efecto</translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="316"/>
        <source>Network connection could not be established</source>
        <translation type="unfinished">No se ha podido establecer la conexión de red</translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="321"/>
        <source>Network connection established</source>
        <translation type="unfinished">Conexión de red establecida</translation>
    </message>
</context>
<context>
    <name>Miscellaneous</name>
    <message>
        <source>Speaker Active</source>
        <translation type="vanished">Altavoz activo</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Miscellaneous.qml" line="13"/>
        <source>Administration Area</source>
        <translation>Área de administración</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Miscellaneous.qml" line="20"/>
        <source>Licences</source>
        <translation type="unfinished">Licencias</translation>
    </message>
</context>
<context>
    <name>MiscellaneousAdmin</name>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="27"/>
        <source>Speaker Active</source>
        <translation type="unfinished">Altavoz activo</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="41"/>
        <source>Communicator Busy</source>
        <translation type="unfinished">Comunicador ocupado</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="47"/>
        <source>Licences</source>
        <translation type="unfinished">Licencias</translation>
    </message>
</context>
<context>
    <name>MoreInformation</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="9"/>
        <source>MORE LICENCE INFORMATION</source>
        <translation type="unfinished">MÁS INFORMACIÓN SOBRE LA LICENCIA</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="22"/>
        <source>For more licence information please visit:</source>
        <translation type="unfinished">Para más información sobre la licencia, visite:</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="32"/>
        <source>https://www.smartterminal.vdo.com/</source>
        <translation type="unfinished">https://www.smartterminal.vdo.com/</translation>
    </message>
</context>
<context>
    <name>Nameserver</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/Nameserver.qml" line="6"/>
        <source>NAMESERVER</source>
        <translation type="unfinished">SERVIDOR DE NOMBRES</translation>
    </message>
</context>
<context>
    <name>Network</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="6"/>
        <source>NETWORK</source>
        <translation>RED</translation>
    </message>
    <message>
        <source>Network Mode</source>
        <translation type="vanished">Modo de red</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="26"/>
        <source>DHCP</source>
        <translation type="unfinished">DHCP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="27"/>
        <source>Disabled</source>
        <translation type="unfinished">Desactivado</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="40"/>
        <source>IP Settings</source>
        <translation>Configuración IP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="46"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="52"/>
        <source>Dataport</source>
        <translation>Puerto de datos</translation>
    </message>
</context>
<context>
    <name>NetworkSettings</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="6"/>
        <source>IP SETTINGS</source>
        <translation>CONFIGURACIÓN IP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="31"/>
        <source>DHCP</source>
        <translation>DHCP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="43"/>
        <source>IP Address</source>
        <translation>Dirección IP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="49"/>
        <source>Broadcast Address</source>
        <translation>Dirección de emisión</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="55"/>
        <source>Subnet Mask</source>
        <translation>Máscara subred</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="61"/>
        <source>Default Gateway</source>
        <translation>Pasarela predeterminada</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="67"/>
        <source>Nameserver</source>
        <translation type="unfinished">Servidor de nombres</translation>
    </message>
</context>
<context>
    <name>NtpPortNumber</name>
    <message>
        <location filename="../qml/content/settings/datetime/ntp/NtpPortNumber.qml" line="10"/>
        <source>NTP PORTNUMBER</source>
        <translation>NÚMERO DE PUERTO NTP</translation>
    </message>
</context>
<context>
    <name>NtpServer</name>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="9"/>
        <source>NTP SERVER</source>
        <translation>SERVIDOR NTP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="28"/>
        <source>NTP Active</source>
        <translation>NTP activo</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="40"/>
        <source>NTP Servername</source>
        <translation>Nombre del servidor NTP</translation>
    </message>
    <message>
        <source>NTP Portnumber</source>
        <translation type="vanished">Número de puerto NTP</translation>
    </message>
</context>
<context>
    <name>NtpServerName</name>
    <message>
        <location filename="../qml/content/settings/datetime/ntp/NtpServerName.qml" line="11"/>
        <source>NTP SERVERNAME</source>
        <translation>NOMBRE DEL SERVIDOR NTP</translation>
    </message>
</context>
<context>
    <name>OperatingMode</name>
    <message>
        <source>Select Mode</source>
        <translation type="vanished">Seleccionar modo</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="44"/>
        <source>USB-Key</source>
        <translation type="unfinished">Llave USB</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="56"/>
        <source>USB-Cable</source>
        <translation type="unfinished">Cable USB</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="68"/>
        <source>Network</source>
        <translation>Red</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="80"/>
        <source>Network Settings</source>
        <translation type="unfinished">Configuración de la red</translation>
    </message>
    <message>
        <source>Standalone</source>
        <translation type="obsolete">Independiente</translation>
    </message>
    <message>
        <source>USB</source>
        <translation type="obsolete">USB</translation>
    </message>
</context>
<context>
    <name>PackageList</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/PackageList.qml" line="9"/>
        <source>PACKAGE LICENCES</source>
        <translation type="unfinished">LICENCIAS DE PAQUETES</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/PackageList.qml" line="25"/>
        <source>Loading package list, please wait.</source>
        <translation type="unfinished">Cargando lista de paquetes, por favor espere.</translation>
    </message>
</context>
<context>
    <name>ResetFrame</name>
    <message>
        <location filename="../qml/content/homescreen/ResetFrame.qml" line="67"/>
        <source>Proceed</source>
        <translation type="unfinished">Proceder</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/ResetFrame.qml" line="105"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>RfidFrame</name>
    <message>
        <location filename="../qml/content/homescreen/RfidFrame.qml" line="23"/>
        <source>RFID TAG RECOGNIZED</source>
        <translation>ETIQUETA RFID RECONOCIDA</translation>
    </message>
</context>
<context>
    <name>Screensaver</name>
    <message>
        <location filename="../qml/content/settings/Screensaver.qml" line="45"/>
        <source>Screensaver Active</source>
        <translation>Salvapantallas activo</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Screensaver.qml" line="57"/>
        <source>Inactivity Timeout</source>
        <translation>Tiempo de espera de inactividad</translation>
    </message>
</context>
<context>
    <name>Select</name>
    <message>
        <source>SELECT</source>
        <translation type="vanished">SELECCIONAR</translation>
    </message>
    <message>
        <source>Standalone</source>
        <translation type="vanished">Independiente</translation>
    </message>
    <message>
        <source>USB</source>
        <translation type="vanished">USB</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="vanished">Red</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../qml/content/Settings.qml" line="8"/>
        <source>INFORMATION</source>
        <translation>INFORMACIÓN</translation>
    </message>
    <message>
        <location filename="../qml/content/Settings.qml" line="13"/>
        <source>LANGUAGE</source>
        <translation>IDIOMA</translation>
    </message>
    <message>
        <location filename="../qml/content/Settings.qml" line="18"/>
        <source>MISCELLANEOUS</source>
        <translation>VARIOS</translation>
    </message>
</context>
<context>
    <name>SettingsAdmin</name>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="6"/>
        <source>INFORMATION</source>
        <translation>INFORMACIÓN</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="11"/>
        <source>LANGUAGE</source>
        <translation>IDIOMA</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="16"/>
        <source>MISCELLANEOUS</source>
        <translation>VARIOS</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="21"/>
        <source>DATE AND TIME</source>
        <translation>FECHA Y HORA</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="26"/>
        <source>SCREENSAVER</source>
        <translation>SALVAPANTALLAS</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="31"/>
        <source>OPERATING MODE</source>
        <translation>MODO OPERATIVO</translation>
    </message>
</context>
<context>
    <name>SubnetMask</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/SubnetMask.qml" line="6"/>
        <source>SUBNET MASK</source>
        <translation>MÁSCARA SUBRED</translation>
    </message>
</context>
<context>
    <name>SumOfDay</name>
    <message>
        <location filename="../qml/content/driveroverview/calendar/SumOfDay.qml" line="14"/>
        <source>EVENT DAY</source>
        <translation>DÍA DEL EVENTO</translation>
    </message>
    <message>
        <source>Work</source>
        <translation type="vanished">Trabajo</translation>
    </message>
    <message>
        <source>Driving</source>
        <translation type="vanished">Conducción</translation>
    </message>
    <message>
        <source>Available</source>
        <translation type="vanished">Disponible</translation>
    </message>
    <message>
        <source>Rest</source>
        <translation type="vanished">Descanso</translation>
    </message>
</context>
<context>
    <name>Systeminfo</name>
    <message>
        <source>USB</source>
        <translation type="obsolete">USB</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="21"/>
        <source>USB-Key</source>
        <translation type="unfinished">Llave USB</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="26"/>
        <source>USB-Cable</source>
        <translation type="unfinished">Cable USB</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="31"/>
        <source>Network</source>
        <translation type="unfinished">Red</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="35"/>
        <source>None</source>
        <translation type="unfinished">Ninguno</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="44"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="50"/>
        <source>S/N</source>
        <translation>N/S</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="56"/>
        <source>IP Address</source>
        <translation>Dirección IP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="62"/>
        <source>Operating Mode</source>
        <translation>Modo operativo</translation>
    </message>
</context>
<context>
    <name>Time</name>
    <message>
        <location filename="../qml/content/settings/datetime/Time.qml" line="10"/>
        <source>TIME</source>
        <translation>HORA</translation>
    </message>
</context>
<context>
    <name>Timeout</name>
    <message>
        <location filename="../qml/content/settings/screensaver/Timeout.qml" line="10"/>
        <source>TIMEOUT</source>
        <translation>TIEMPO DE ESPERA</translation>
    </message>
</context>
<context>
    <name>UpdateErrorFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UpdateErrorFrame.qml" line="66"/>
        <source>Proceed</source>
        <translation type="unfinished">Proceder</translation>
    </message>
</context>
<context>
    <name>UpdateFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UpdateFrame.qml" line="82"/>
        <source>Proceed</source>
        <translation type="unfinished">Proceder</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/UpdateFrame.qml" line="113"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>UsbOverview</name>
    <message>
        <location filename="../qml/content/UsbOverview.qml" line="12"/>
        <source>DRIVER</source>
        <translation>CONDUCTOR</translation>
    </message>
    <message>
        <location filename="../qml/content/UsbOverview.qml" line="18"/>
        <source>VEHICLE INFORMATION</source>
        <translation>INFORMACIÓN DEL VEHÍCULO</translation>
    </message>
</context>
<context>
    <name>VehicleInformation</name>
    <message>
        <location filename="../qml/content/usboverview/vehicleselect/VehicleInformation.qml" line="51"/>
        <source>Start</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <location filename="../qml/content/usboverview/vehicleselect/VehicleInformation.qml" line="82"/>
        <source>End</source>
        <translation>Fin</translation>
    </message>
</context>
<context>
    <name>WiFiPassword</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/wifi/WiFiPassword.qml" line="11"/>
        <source>WIFI PASSWORD</source>
        <translation>CONTRASEÑA WIFI</translation>
    </message>
</context>
<context>
    <name>WiFiSSID</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/wifi/WiFiSSID.qml" line="10"/>
        <source>WIFI SSID</source>
        <translation>WIFI SSID</translation>
    </message>
</context>
<context>
    <name>WiFiSettings</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="6"/>
        <source>WIFI SETTINGS</source>
        <translation>CONFIGURACIÓN WIFI</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="25"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="38"/>
        <source>WiFi SSID</source>
        <translation>WiFi SSID</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="44"/>
        <source>WiFi Password</source>
        <translation>Contraseña WiFi</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="50"/>
        <source>WiFi Available Networks</source>
        <translation type="unfinished">Redes wifi disponibles</translation>
    </message>
</context>
<context>
    <name>Zone</name>
    <message>
        <location filename="../qml/content/settings/datetime/Zone.qml" line="9"/>
        <source>TIMEZONE</source>
        <translation>ZONA HORARIA</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>VDO Terminal v4</source>
        <translation type="vanished">Terminal VDO v4</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="77"/>
        <source>VDO SmartTerminal</source>
        <translation type="unfinished">Terminal inteligente VDO</translation>
    </message>
</context>
</TS>
