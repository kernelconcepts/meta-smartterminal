<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ActivityMeta</name>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="33"/>
        <source>Rest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="34"/>
        <source>Available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="35"/>
        <source>Work</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="36"/>
        <source>Driving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="37"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdminPassword</name>
    <message>
        <location filename="../qml/content/settings/AdminPassword.qml" line="10"/>
        <source>ADMINISTRATION AREA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BroadcastAddress</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/BroadcastAddress.qml" line="6"/>
        <source>BROADCAST ADDRESS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dataport</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/Dataport.qml" line="10"/>
        <source>DATAPORT</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Date</name>
    <message>
        <location filename="../qml/content/settings/datetime/Date.qml" line="10"/>
        <source>DATE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateTime</name>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="9"/>
        <source>disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="45"/>
        <source>NTP Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="51"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="57"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="63"/>
        <source>Time Zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="69"/>
        <source>Daylight Saving Time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DemoEvent</name>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="11"/>
        <source>DETAILS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="53"/>
        <source>License Plate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="85"/>
        <source>From:</source>
        <extracomment>Timespan</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="117"/>
        <source>Till:</source>
        <extracomment>Timespan</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadCardLabel</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="19"/>
        <source>DRIVERCARD DOWNLOAD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="26"/>
        <source>WORKSHOPCARD DOWNLOAD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="33"/>
        <source>COMPANYCARD DOWNLOAD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="40"/>
        <source>KEY DOWNLOAD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadError</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="44"/>
        <source>CARD READ OR DOWNLOAD ERROR&lt;br&gt;Please check card orientation. Chip facing away from you.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="60"/>
        <source>Invalid Card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="79"/>
        <source>DOWNLOAD KEY READ OR DOWNLOAD ERROR.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadFrame</name>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="102"/>
        <source>PLEASE SCAN DRIVER LICENSE!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="125"/>
        <source>PROCEED WITHOUT LICENSE SCAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="163"/>
        <source>OPEN DOWNLOAD KEY MENU</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadFrameSmall</name>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="168"/>
        <source>PLEASE SCAN DRIVER LICENSE!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="201"/>
        <source>PROCEED WITHOUT LICENSE SCAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="239"/>
        <source>OPEN DOWNLOAD KEY MENU</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadRfid</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="38"/>
        <source>VALID RFID TAG FOUND!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="54"/>
        <source>FOUND RFID TAG. READING, PLEASE WAIT.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="61"/>
        <source>READING VALID RFID TAG DONE.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="68"/>
        <source>AN ERROR OCCURED WHILE READING RFID TAG.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="79"/>
        <source>FOUND INVALID RFID TAG.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DrivenVehicles</name>
    <message>
        <location filename="../qml/content/driveroverview/DrivenVehicles.qml" line="60"/>
        <source>from</source>
        <extracomment>Timespan</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DrivenVehicles.qml" line="60"/>
        <source>till</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DriverInformation</name>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="13"/>
        <source>Last Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="18"/>
        <source>Next Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="23"/>
        <source>Next Break</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="27"/>
        <source>Remaining Driving Time (Daily)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="31"/>
        <source>Remaining Driving Time (Week)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="36"/>
        <source>Remaining extended driving time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="41"/>
        <source>Remaining reduced daily rest time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="46"/>
        <source>Sum break time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="51"/>
        <source>Sum driving time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="56"/>
        <source>Sum working time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="61"/>
        <source>Last activity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DriverOverview</name>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="8"/>
        <source>DRIVER INFORMATION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="13"/>
        <source>DRIVEN VEHICLES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="19"/>
        <source>EVENTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="25"/>
        <source>CALENDAR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="31"/>
        <source>INFORMATION</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorConfiguration</name>
    <message>
        <location filename="../qml/content/errors/ErrorConfiguration.qml" line="6"/>
        <source>Configuration incomplete! System not functional!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorFrame</name>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="17"/>
        <source>HOME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="22"/>
        <source>Proceed with factory reset?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="29"/>
        <source>Proceed with system update?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="36"/>
        <source>Transfer of system update to device in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="44"/>
        <source>Installation of system update in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="52"/>
        <source>An error occured during update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="60"/>
        <source>USB Operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="73"/>
        <source>Your changes have been applied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/ErrorFrame.qml" line="103"/>
        <source>System is going to reboot</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorMessages</name>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="24"/>
        <source>Unknown System Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="25"/>
        <source>Logging Facility Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="26"/>
        <source>Smartcard Reader Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="27"/>
        <source>Touchscreen Detection Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="28"/>
        <source>Rfid Reader Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="30"/>
        <source>Encryption Key Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="32"/>
        <source>One or more files are corrupted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="29"/>
        <source>Configuration Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="31"/>
        <source>Serial Number Failure</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorMultipleDataCarrier</name>
    <message>
        <location filename="../qml/content/errors/ErrorMultipleDataCarrier.qml" line="6"/>
        <source>Multiple Data Carrier Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorNTP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNTP.qml" line="6"/>
        <source>NTP Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorNetworkDHCP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkDHCP.qml" line="6"/>
        <source>DHCP Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorNetworkIP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkIP.qml" line="6"/>
        <source>Network IP Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorNetworkWiFi</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkWiFi.qml" line="6"/>
        <source>WiFi Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorRFID</name>
    <message>
        <location filename="../qml/content/errors/ErrorRFID.qml" line="6"/>
        <source>RFID Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorSCard</name>
    <message>
        <location filename="../qml/content/errors/ErrorSCard.qml" line="6"/>
        <source>SmartCard Error. Please check card orientation. Chip facing away from you.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorSaveSettings</name>
    <message>
        <location filename="../qml/content/errors/ErrorSaveSettings.qml" line="6"/>
        <source>Save Settings Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorTime</name>
    <message>
        <location filename="../qml/content/errors/ErrorTime.qml" line="6"/>
        <source>Manual Time Set Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorUSBKey</name>
    <message>
        <location filename="../qml/content/errors/ErrorUSBKey.qml" line="6"/>
        <source>USB Key Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EventDetails</name>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="12"/>
        <source>DETAILS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="58"/>
        <source>License Plate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="90"/>
        <source>From:</source>
        <extracomment>Timespan</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="133"/>
        <source>Till:</source>
        <extracomment>Timespan</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EventMessages</name>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="97"/>
        <source>No further details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="98"/>
        <source>Insertion of non-valid card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="99"/>
        <source>Card conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="100"/>
        <source>Time overlap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="101"/>
        <source>Driving without an appropriate card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="102"/>
        <source>Card insertion while driving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="103"/>
        <source>Last card session not correctly closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="104"/>
        <source>Over speeding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="105"/>
        <source>Power supply interruption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="106"/>
        <source>Motion data error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="107"/>
        <source>Vehicle motion conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="108"/>
        <source>Time conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="109"/>
        <source>Communication error with the remote communication facility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="110"/>
        <source>Absence of position information from GNSS receiver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="111"/>
        <source>Communication error with the external GNSS facility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="113"/>
        <source>Motion sensor authentication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="114"/>
        <source>Tachograph card authentication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="115"/>
        <source>Unauthorised change of motion sensor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="116"/>
        <source>Card data input integrity error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="117"/>
        <source>Stored user data integrity error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="118"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="127"/>
        <source>Internal data transfer error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="119"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="128"/>
        <source>Unauthorised case opening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="120"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="129"/>
        <source>Hardware sabotage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="121"/>
        <source>Tamper detection of GNSS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="122"/>
        <source>External GNSS facility authentication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="123"/>
        <source>External GNSS facility certificate expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="125"/>
        <source>Authentication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="126"/>
        <source>Stored data integrity error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="131"/>
        <source>VU internal fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="132"/>
        <source>Printer fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="133"/>
        <source>Display fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="134"/>
        <source>Downloading fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="135"/>
        <source>Sensor fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="136"/>
        <source>Internal GNSS receiver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="137"/>
        <source>External GNSS facility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="138"/>
        <source>Remote communication facility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="139"/>
        <source>ITS interface</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EventsOfDayList</name>
    <message>
        <location filename="../qml/content/driveroverview/calendar/EventsOfDayList.qml" line="13"/>
        <source>DETAILS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Gateway</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/Gateway.qml" line="6"/>
        <source>DEFAULT GATEWAY</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Homescreen</name>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="12"/>
        <source>HOME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="18"/>
        <source>Proceed with factory reset?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="25"/>
        <source>Proceed with system update?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="32"/>
        <source>Transfer of system update to device in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="40"/>
        <source>Installation of system update in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="48"/>
        <source>An error occured during update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="97"/>
        <source>USB Operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="104"/>
        <source>Your changes have been applied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="110"/>
        <source>System is going to reboot</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoLocalConfiguration</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoLocalConfiguration.qml" line="6"/>
        <source>Local Configuration Pending</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoRemoteAccess</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoRemoteAccess.qml" line="6"/>
        <source>Remote Access</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoUpdatePending</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoUpdatePending.qml" line="6"/>
        <source>Update Pending</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IpAddress</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/IpAddress.qml" line="6"/>
        <source>IP ADDRESS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Keyboard</name>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="44"/>
        <source>q</source>
        <extracomment>Keyboard normal Key Q</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="45"/>
        <source>w</source>
        <extracomment>Keyboard normal Key W</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="46"/>
        <source>e</source>
        <extracomment>Keyboard normal Key E</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="47"/>
        <source>r</source>
        <extracomment>Keyboard normal Key R</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="48"/>
        <source>t</source>
        <extracomment>Keyboard normal Key T</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="49"/>
        <source>z</source>
        <extracomment>Keyboard normal Key Z</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="50"/>
        <source>u</source>
        <extracomment>Keyboard normal Key U</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="51"/>
        <source>i</source>
        <extracomment>Keyboard normal Key I</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="52"/>
        <source>o</source>
        <extracomment>Keyboard normal Key O</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="53"/>
        <source>p</source>
        <extracomment>Keyboard normal Key P</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="55"/>
        <source>a</source>
        <extracomment>Keyboard normal Key A</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="56"/>
        <source>s</source>
        <extracomment>Keyboard normal Key S</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="57"/>
        <source>d</source>
        <extracomment>Keyboard normal Key D</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="58"/>
        <source>f</source>
        <extracomment>Keyboard normal Key F</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="59"/>
        <source>g</source>
        <extracomment>Keyboard normal Key G</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="60"/>
        <source>h</source>
        <extracomment>Keyboard normal Key H</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="61"/>
        <source>j</source>
        <extracomment>Keyboard normal Key J</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="62"/>
        <source>k</source>
        <extracomment>Keyboard normal Key K</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="63"/>
        <source>l</source>
        <extracomment>Keyboard normal Key L</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="64"/>
        <source>ü</source>
        <extracomment>Keyboard normal Key Ü</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="66"/>
        <source>y</source>
        <extracomment>Keyboard normal Key Y</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="67"/>
        <source>x</source>
        <extracomment>Keyboard normal Key X</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="68"/>
        <source>c</source>
        <extracomment>Keyboard normal Key C</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="69"/>
        <source>v</source>
        <extracomment>Keyboard normal Key V</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="70"/>
        <source>b</source>
        <extracomment>Keyboard normal Key B</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="71"/>
        <source>n</source>
        <extracomment>Keyboard normal Key N</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="72"/>
        <source>m</source>
        <extracomment>Keyboard normal Key M</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="73"/>
        <source>ö</source>
        <extracomment>Keyboard normal Key Ö</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="74"/>
        <source>ä</source>
        <extracomment>Keyboard normal Key Ä</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="75"/>
        <location filename="../qml/components/misc/Keyboard.qml" line="185"/>
        <source>-</source>
        <extracomment>Keyboard normal Key -
----------
Keyboard special Key Z</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="105"/>
        <source>=/&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="143"/>
        <source>Q</source>
        <extracomment>Keyboard capsLock Key Q</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="144"/>
        <source>W</source>
        <extracomment>Keyboard capsLock Key W</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="145"/>
        <source>E</source>
        <extracomment>Keyboard capsLock Key E</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="146"/>
        <source>R</source>
        <extracomment>Keyboard capsLock Key R</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="147"/>
        <source>T</source>
        <extracomment>Keyboard capsLock Key T</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="148"/>
        <source>Z</source>
        <extracomment>Keyboard capsLock Key Z</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="149"/>
        <source>U</source>
        <extracomment>Keyboard capsLock Key U</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="150"/>
        <source>I</source>
        <extracomment>Keyboard capsLock Key I</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="151"/>
        <source>O</source>
        <extracomment>Keyboard capsLock Key O</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="152"/>
        <source>P</source>
        <extracomment>Keyboard capsLock Key P</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="154"/>
        <source>A</source>
        <extracomment>Keyboard capsLock Key A</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="155"/>
        <source>S</source>
        <extracomment>Keyboard capsLock Key S</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="156"/>
        <source>D</source>
        <extracomment>Keyboard capsLock Key D</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="157"/>
        <source>F</source>
        <extracomment>Keyboard capsLock Key F</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="158"/>
        <source>G</source>
        <extracomment>Keyboard capsLock Key G</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="159"/>
        <source>H</source>
        <extracomment>Keyboard capsLock Key H</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="160"/>
        <source>J</source>
        <extracomment>Keyboard capsLock Key J</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="161"/>
        <source>K</source>
        <extracomment>Keyboard capsLock Key K</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="162"/>
        <source>L</source>
        <extracomment>Keyboard capsLock Key L</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="163"/>
        <source>Ü</source>
        <extracomment>Keyboard capsLock Key Ü</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="165"/>
        <source>Y</source>
        <extracomment>Keyboard capsLock Key Y</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="166"/>
        <source>X</source>
        <extracomment>Keyboard capsLock Key X</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="167"/>
        <source>C</source>
        <extracomment>Keyboard capsLock Key C</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="168"/>
        <source>V</source>
        <extracomment>Keyboard capsLock Key V</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="169"/>
        <source>B</source>
        <extracomment>Keyboard capsLock Key B</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="170"/>
        <source>N</source>
        <extracomment>Keyboard capsLock Key N</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="171"/>
        <source>M</source>
        <extracomment>Keyboard capsLock Key M</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="172"/>
        <source>Ö</source>
        <extracomment>Keyboard capsLock Key Ö</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="173"/>
        <source>Ä</source>
        <extracomment>Keyboard capsLock Key Ä</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="174"/>
        <source>_</source>
        <extracomment>Keyboard capsLock Key -</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="180"/>
        <source>@</source>
        <extracomment>Keyboard special Key Q</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="181"/>
        <source>#</source>
        <extracomment>Keyboard special Key W</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="182"/>
        <source>€</source>
        <extracomment>Keyboard special Key E</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="183"/>
        <source>$</source>
        <extracomment>Keyboard special Key R</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="184"/>
        <source>&amp;</source>
        <extracomment>Keyboard special Key T</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="186"/>
        <source>+</source>
        <extracomment>Keyboard special Key U</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="187"/>
        <source>*</source>
        <extracomment>Keyboard special Key I</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="188"/>
        <source>/</source>
        <extracomment>Keyboard special Key O</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="189"/>
        <source>=</source>
        <extracomment>Keyboard special Key P</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="191"/>
        <source>%</source>
        <extracomment>Keyboard special Key A</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="192"/>
        <source>&quot;</source>
        <extracomment>Keyboard special Key S</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="193"/>
        <source>&apos;</source>
        <extracomment>Keyboard special Key D</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="194"/>
        <source>:</source>
        <extracomment>Keyboard special Key F</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="195"/>
        <source>;</source>
        <extracomment>Keyboard special Key G</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="196"/>
        <source>!</source>
        <extracomment>Keyboard special Key H</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="197"/>
        <source>?</source>
        <extracomment>Keyboard special Key J</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="198"/>
        <source>~</source>
        <extracomment>Keyboard special Key K</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="199"/>
        <source>|</source>
        <extracomment>Keyboard special Key L</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="200"/>
        <source>§</source>
        <extracomment>Keyboard special Key Ü</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="202"/>
        <source>(</source>
        <extracomment>Keyboard special Key Y</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="203"/>
        <source>)</source>
        <extracomment>Keyboard special Key X</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="204"/>
        <source>{</source>
        <extracomment>Keyboard special Key C</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="205"/>
        <source>}</source>
        <extracomment>Keyboard special Key V</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="206"/>
        <source>[</source>
        <extracomment>Keyboard special Key B</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="207"/>
        <source>]</source>
        <extracomment>Keyboard special Key N</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="208"/>
        <source>&lt;</source>
        <extracomment>Keyboard special Key M</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="209"/>
        <source>&gt;</source>
        <extracomment>Keyboard special Key Ö</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="210"/>
        <source>,</source>
        <extracomment>Keyboard special Key Ä</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="211"/>
        <source>.</source>
        <extracomment>Keyboard special Key -</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Licence</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="6"/>
        <source>LICENCES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="13"/>
        <source>Package List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="20"/>
        <source>More Information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainFooter</name>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="127"/>
        <source>Your changes have been applied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="162"/>
        <source>Reboot pending for changes to take effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="316"/>
        <source>Network connection could not be established</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="321"/>
        <source>Network connection established</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Miscellaneous</name>
    <message>
        <location filename="../qml/content/settings/Miscellaneous.qml" line="13"/>
        <source>Administration Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Miscellaneous.qml" line="20"/>
        <source>Licences</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MiscellaneousAdmin</name>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="27"/>
        <source>Speaker Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="41"/>
        <source>Communicator Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="47"/>
        <source>Licences</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MoreInformation</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="9"/>
        <source>MORE LICENCE INFORMATION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="22"/>
        <source>For more licence information please visit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="32"/>
        <source>https://www.smartterminal.vdo.com/</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Nameserver</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/Nameserver.qml" line="6"/>
        <source>NAMESERVER</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Network</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="6"/>
        <source>NETWORK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="26"/>
        <source>DHCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="27"/>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="40"/>
        <source>IP Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="46"/>
        <source>WiFi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="52"/>
        <source>Dataport</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkSettings</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="6"/>
        <source>IP SETTINGS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="31"/>
        <source>DHCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="43"/>
        <source>IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="49"/>
        <source>Broadcast Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="55"/>
        <source>Subnet Mask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="61"/>
        <source>Default Gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="67"/>
        <source>Nameserver</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NtpPortNumber</name>
    <message>
        <location filename="../qml/content/settings/datetime/ntp/NtpPortNumber.qml" line="10"/>
        <source>NTP PORTNUMBER</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NtpServer</name>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="9"/>
        <source>NTP SERVER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="28"/>
        <source>NTP Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="40"/>
        <source>NTP Servername</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NtpServerName</name>
    <message>
        <location filename="../qml/content/settings/datetime/ntp/NtpServerName.qml" line="11"/>
        <source>NTP SERVERNAME</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OperatingMode</name>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="44"/>
        <source>USB-Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="56"/>
        <source>USB-Cable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="68"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="80"/>
        <source>Network Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PackageList</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/PackageList.qml" line="9"/>
        <source>PACKAGE LICENCES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/PackageList.qml" line="25"/>
        <source>Loading package list, please wait.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResetFrame</name>
    <message>
        <location filename="../qml/content/homescreen/ResetFrame.qml" line="67"/>
        <source>Proceed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/ResetFrame.qml" line="105"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RfidFrame</name>
    <message>
        <location filename="../qml/content/homescreen/RfidFrame.qml" line="23"/>
        <source>RFID TAG RECOGNIZED</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Screensaver</name>
    <message>
        <location filename="../qml/content/settings/Screensaver.qml" line="45"/>
        <source>Screensaver Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Screensaver.qml" line="57"/>
        <source>Inactivity Timeout</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../qml/content/Settings.qml" line="8"/>
        <source>INFORMATION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Settings.qml" line="13"/>
        <source>LANGUAGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/Settings.qml" line="18"/>
        <source>MISCELLANEOUS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsAdmin</name>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="6"/>
        <source>INFORMATION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="11"/>
        <source>LANGUAGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="16"/>
        <source>MISCELLANEOUS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="21"/>
        <source>DATE AND TIME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="26"/>
        <source>SCREENSAVER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="31"/>
        <source>OPERATING MODE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubnetMask</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/SubnetMask.qml" line="6"/>
        <source>SUBNET MASK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SumOfDay</name>
    <message>
        <location filename="../qml/content/driveroverview/calendar/SumOfDay.qml" line="14"/>
        <source>EVENT DAY</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Systeminfo</name>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="21"/>
        <source>USB-Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="26"/>
        <source>USB-Cable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="31"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="35"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="44"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="50"/>
        <source>S/N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="56"/>
        <source>IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="62"/>
        <source>Operating Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Time</name>
    <message>
        <location filename="../qml/content/settings/datetime/Time.qml" line="10"/>
        <source>TIME</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Timeout</name>
    <message>
        <location filename="../qml/content/settings/screensaver/Timeout.qml" line="10"/>
        <source>TIMEOUT</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateErrorFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UpdateErrorFrame.qml" line="66"/>
        <source>Proceed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UpdateFrame.qml" line="82"/>
        <source>Proceed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/UpdateFrame.qml" line="113"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsbOverview</name>
    <message>
        <location filename="../qml/content/UsbOverview.qml" line="12"/>
        <source>DRIVER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/UsbOverview.qml" line="18"/>
        <source>VEHICLE INFORMATION</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VehicleInformation</name>
    <message>
        <location filename="../qml/content/usboverview/vehicleselect/VehicleInformation.qml" line="51"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/usboverview/vehicleselect/VehicleInformation.qml" line="82"/>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WiFiPassword</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/wifi/WiFiPassword.qml" line="11"/>
        <source>WIFI PASSWORD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WiFiSSID</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/wifi/WiFiSSID.qml" line="10"/>
        <source>WIFI SSID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WiFiSettings</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="6"/>
        <source>WIFI SETTINGS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="25"/>
        <source>WiFi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="38"/>
        <source>WiFi SSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="44"/>
        <source>WiFi Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="50"/>
        <source>WiFi Available Networks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Zone</name>
    <message>
        <location filename="../qml/content/settings/datetime/Zone.qml" line="9"/>
        <source>TIMEZONE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="77"/>
        <source>VDO SmartTerminal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
