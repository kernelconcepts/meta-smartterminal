<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>ActivityMeta</name>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="33"/>
        <source>Rest</source>
        <translation>Pihenés</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="34"/>
        <source>Available</source>
        <translation>Elérhető</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="35"/>
        <source>Work</source>
        <translation>Munka</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="36"/>
        <source>Driving</source>
        <translation>Vezetés</translation>
    </message>
    <message>
        <location filename="../qml/imports/ActivityMeta/ActivityMeta.qml" line="37"/>
        <source>Unknown</source>
        <translation>Ismeretlen</translation>
    </message>
</context>
<context>
    <name>AdminPassword</name>
    <message>
        <location filename="../qml/content/settings/AdminPassword.qml" line="10"/>
        <source>ADMINISTRATION AREA</source>
        <translation>ADMINISZTRÁCIÓS TERÜLET</translation>
    </message>
</context>
<context>
    <name>BaseFrame</name>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="20"/>
        <source>HOME</source>
        <translation>KEZDŐLAP</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="49"/>
        <source>System is going to reboot</source>
        <translation>A rendszer újraindul</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="94"/>
        <source>USB Operation</source>
        <translation>Az USB működése</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="103"/>
        <source>USB KEY REMOVED.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="120"/>
        <source>Proceed with factory reset?</source>
        <translation>Folytatja a gyári visszaállítást?</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="140"/>
        <source>Proceed with system update?</source>
        <translation>Folytatja a rendszerfrissítéssel?</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="182"/>
        <source>Transfer of system update to device in progress</source>
        <translation>A rendszerfrissítés átvitele az eszközre folyamatban</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="190"/>
        <source>Installation of system update in progress</source>
        <translation>A rendszerfrissítés telepítése folyamatban</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="198"/>
        <source>An error occured during update!</source>
        <translation>Hiba történt a frissítés során!</translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="205"/>
        <source>Welcome to the VDO experience. The SmartTerminal now needs to be configured via the VDO TerminalTools software.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="206"/>
        <source>Take me to the network settings</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/BaseFrame.qml" line="220"/>
        <source>Your changes have been applied</source>
        <translation>Változtatások végrehajtva</translation>
    </message>
</context>
<context>
    <name>BroadcastAddress</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/BroadcastAddress.qml" line="6"/>
        <source>BROADCAST ADDRESS</source>
        <translation>Közvetői cím</translation>
    </message>
</context>
<context>
    <name>CommunicationHandler</name>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="17"/>
        <source>Write device configuration</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="18"/>
        <source>Read device configuration</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="19"/>
        <source>List directory content</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="20"/>
        <source>Read data from device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="21"/>
        <source>Archive data on device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="22"/>
        <source>Delete data on device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="23"/>
        <source>Update device firmware</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="24"/>
        <source>Reboot device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="25"/>
        <source>Read system information</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="26"/>
        <source>Reset device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="27"/>
        <source>Set date and time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="28"/>
        <source>Announce operation</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="29"/>
        <source>Service start/stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../backend/communicationhandler.cpp" line="674"/>
        <source>Unknown command</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CryptoDLKPwFrame</name>
    <message>
        <location filename="../qml/content/homescreen/CryptoDLKPwFrame.qml" line="98"/>
        <source>Locked Download Key detected.&lt;br&gt;&lt;br&gt;Please enter PIN.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/CryptoDLKPwFrame.qml" line="113"/>
        <source>Unlock</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Dataport</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/Dataport.qml" line="10"/>
        <source>DATAPORT</source>
        <translation>ADATPORT</translation>
    </message>
</context>
<context>
    <name>Date</name>
    <message>
        <location filename="../qml/content/settings/datetime/Date.qml" line="10"/>
        <source>DATE</source>
        <translation>DÁTUM</translation>
    </message>
</context>
<context>
    <name>DateTime</name>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="9"/>
        <source>disabled</source>
        <translation>Kikapcsolva</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="45"/>
        <source>NTP Server</source>
        <translation>NTP-kiszolgáló</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="51"/>
        <source>Date</source>
        <translation>Dátum</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="57"/>
        <source>Time</source>
        <translation>Idő</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="63"/>
        <source>Time Zone</source>
        <translation>Időzóna</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/DateTime.qml" line="69"/>
        <source>Daylight Saving Time</source>
        <translation>Nyári időszámítás</translation>
    </message>
</context>
<context>
    <name>DemoEvent</name>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="11"/>
        <source>DETAILS</source>
        <translation>RÉSZLETEK</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="53"/>
        <source>License Plate:</source>
        <translation>Rendszám:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="85"/>
        <source>From:</source>
        <extracomment>Timespan</extracomment>
        <translation>Küldő:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/DemoEvent.qml" line="117"/>
        <source>Till:</source>
        <extracomment>Timespan</extracomment>
        <translation>Eddig:</translation>
    </message>
</context>
<context>
    <name>DownloadCardLabel</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="19"/>
        <source>DRIVERCARD DOWNLOAD</source>
        <translation>JÁRMŰVEZETŐI KÁRTYA LETÖLTÉSE</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="26"/>
        <source>WORKSHOPCARD DOWNLOAD</source>
        <translation>MŰHELY KÁRTYA LETÖLTÉSE</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="33"/>
        <source>COMPANYCARD DOWNLOAD</source>
        <translation>VÁLLALATI KÁRTYA LETÖLTÉSE</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadCardLabel.qml" line="40"/>
        <source>KEY DOWNLOAD</source>
        <translation>KULCS LETÖLTÉSE</translation>
    </message>
</context>
<context>
    <name>DownloadError</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="44"/>
        <source>CARD READ OR DOWNLOAD ERROR&lt;br&gt;Please check card orientation. Chip facing away from you.</source>
        <translation>KÁRTYABEOLVASÁSI VAGY LETÖLTÉSI HIBA&lt;br&gt;Kérjük, nézze meg merre néz a kártya. A chip Öntől messzebb van.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="60"/>
        <source>Invalid Card</source>
        <translation>Érvénytelen kártya</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadError.qml" line="79"/>
        <source>DOWNLOAD KEY READ OR DOWNLOAD ERROR.</source>
        <translation>LETÖLTŐ KULCS OLVASÁSA VAGY LETÖLTÉSI HIBA.</translation>
    </message>
    <message>
        <source>CARD REMOVED TOO EARLY</source>
        <translation type="vanished">TÚL KORÁN ELVETTE A KÁRTYÁT</translation>
    </message>
    <message>
        <source>INSERTED INVALID CARD</source>
        <translation type="vanished">ÉRVÉNYTELEN KÁRTYÁT HELYEZETT BE</translation>
    </message>
    <message>
        <source>INVALID RFID TAG</source>
        <translation type="vanished">ÉRVÉNYTELEN RF-AZONOSÍTÓ CÍMKE</translation>
    </message>
    <message>
        <source>RFID TAG READ ERROR</source>
        <translation type="vanished">RF-AZONOSÍTÓ CÍMKE BEOLVASÁSI HIBA</translation>
    </message>
</context>
<context>
    <name>DownloadFrame</name>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="102"/>
        <source>PLEASE SCAN DRIVER LICENSE!</source>
        <translation>KÉRJÜK, OLVASSA LE A JÁRMŰVEZETŐI KÁRTYÁJÁT!</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="125"/>
        <source>PROCEED WITHOUT LICENSE SCAN</source>
        <translation>A RENDSZÁM BEOLVASÁSA NÉLKÜL FOLYTASSA</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrame.qml" line="163"/>
        <source>OPEN DOWNLOAD KEY MENU</source>
        <translation>LETÖLTŐ KULCS MENÜJE NYITVA</translation>
    </message>
</context>
<context>
    <name>DownloadFrameSmall</name>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="168"/>
        <source>PLEASE SCAN DRIVER LICENSE!</source>
        <translation>KÉRJÜK, OLVASSA LE A JÁRMŰVEZETŐI KÁRTYÁJÁT!</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="201"/>
        <source>PROCEED WITHOUT LICENSE SCAN</source>
        <translation>A RENDSZÁM BEOLVASÁSA NÉLKÜL FOLYTASSA</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/DownloadFrameSmall.qml" line="239"/>
        <source>OPEN DOWNLOAD KEY MENU</source>
        <translation>LETÖLTŐ KULCS MENÜJE NYITVA</translation>
    </message>
</context>
<context>
    <name>DownloadRfid</name>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="38"/>
        <source>VALID RFID TAG FOUND!</source>
        <translation>ÉRVÉNYES RF-AZONOSÍTÓ CÍMKÉT TALÁLT!</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="54"/>
        <source>FOUND RFID TAG. READING, PLEASE WAIT.</source>
        <translation>MEGTALÁLT RF-AZONOSÍTÓ CÍMKE. BEOLVASÁS FOLYAMATBAN, KÉREM, VÁRJON.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="61"/>
        <source>READING VALID RFID TAG DONE.</source>
        <translation>AZ ÉRVÉNYES RF-AZONOSÍTÓ CÍMKE BEOLVASÁSA KÉSZ.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="68"/>
        <source>AN ERROR OCCURED WHILE READING RFID TAG.</source>
        <translation>RF-AZONOSÍTÓ CÍMKE BEOLVASÁSI HIBA.</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/download/DownloadRfid.qml" line="79"/>
        <source>FOUND INVALID RFID TAG.</source>
        <translation>ÉRVÉNYTELEN RF-AZONOSÍTÓ CÍMKE.</translation>
    </message>
</context>
<context>
    <name>DrivenVehicles</name>
    <message>
        <location filename="../qml/content/driveroverview/DrivenVehicles.qml" line="60"/>
        <source>from</source>
        <extracomment>Timespan</extracomment>
        <translation>tól</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DrivenVehicles.qml" line="60"/>
        <source>till</source>
        <translation>ig</translation>
    </message>
</context>
<context>
    <name>DriverInformation</name>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="13"/>
        <source>Last Download</source>
        <translation>Utolsó letöltés</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="18"/>
        <source>Next Download</source>
        <translation>Következő letöltés</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="23"/>
        <source>Next Break</source>
        <translation>Következő szünet</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="27"/>
        <source>Remaining Driving Time (Daily)</source>
        <translation>Fennmaradó vezetési idő (naponta)</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="31"/>
        <source>Remaining Driving Time (Week)</source>
        <translation>Fennmaradó vezetési idő (hetente)</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="36"/>
        <source>Remaining extended driving time</source>
        <translation>Fennmaradó meghosszabbított vezetési idő</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="41"/>
        <source>Remaining reduced daily rest time</source>
        <translation>Fennmaradó csökkentett napi pihenési idő</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="46"/>
        <source>Sum break time</source>
        <translation>Összes szünetidő</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="51"/>
        <source>Sum driving time</source>
        <translation>Összes vezetési idő</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="56"/>
        <source>Sum working time</source>
        <translation>Összes munkaidő</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/DriverInformation.qml" line="61"/>
        <source>Last activity</source>
        <translation>Utolsó tevékenység</translation>
    </message>
</context>
<context>
    <name>DriverOverview</name>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="8"/>
        <source>DRIVER INFORMATION</source>
        <translation>JÁRMŰVEZETŐI INFORMÁCIÓ</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="13"/>
        <source>DRIVEN VEHICLES</source>
        <translation>VEZETETT JÁRMŰVEK</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="19"/>
        <source>EVENTS</source>
        <translation>ESEMÉNYEK</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="25"/>
        <source>CALENDAR</source>
        <translation>NAPTÁR</translation>
    </message>
    <message>
        <location filename="../qml/content/DriverOverview.qml" line="31"/>
        <source>INFORMATION</source>
        <translation>INFORMÁCIÓ</translation>
    </message>
</context>
<context>
    <name>ErrorConfiguration</name>
    <message>
        <location filename="../qml/content/errors/ErrorConfiguration.qml" line="6"/>
        <source>Configuration incomplete! System not functional!</source>
        <translation>Befejezetlen konfiguráció! A rendszer működésképtelen!</translation>
    </message>
</context>
<context>
    <name>ErrorFrame</name>
    <message>
        <source>HOME</source>
        <translation type="vanished">KEZDŐLAP</translation>
    </message>
    <message>
        <source>Proceed with factory reset?</source>
        <translation type="vanished">Folytatja a gyári visszaállítást?</translation>
    </message>
    <message>
        <source>Proceed with system update?</source>
        <translation type="vanished">Folytatja a rendszerfrissítéssel?</translation>
    </message>
    <message>
        <source>Transfer of system update to device in progress</source>
        <translation type="obsolete">A rendszerfrissítés átvitele az eszközre folyamatban</translation>
    </message>
    <message>
        <source>Installation of system update in progress</source>
        <translation type="obsolete">A rendszerfrissítés telepítése folyamatban</translation>
    </message>
    <message>
        <source>An error occured during update!</source>
        <translation type="vanished">Hiba történt a frissítés során!</translation>
    </message>
    <message>
        <source>USB Operation</source>
        <translation type="obsolete">Az USB működése</translation>
    </message>
    <message>
        <source>Your changes have been applied</source>
        <translation type="obsolete">Változtatások végrehajtva</translation>
    </message>
    <message>
        <source>System is going to reboot</source>
        <translation type="obsolete">A rendszer újraindul</translation>
    </message>
</context>
<context>
    <name>ErrorMessages</name>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="25"/>
        <source>Unknown System Failure</source>
        <translation>Ismeretlen rendszerhiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="26"/>
        <source>Logging Facility Failure</source>
        <translation>Bejelentkezési hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="27"/>
        <source>Smartcard Reader Failure</source>
        <translation>Kártya olvasó hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="28"/>
        <source>Touchscreen Detection Failure</source>
        <translation>Érintőképernyő érzékelési hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="29"/>
        <source>Rfid Reader Failure</source>
        <translation>Az Rfid olvasó hibája</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="31"/>
        <source>Configuration Missing</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="32"/>
        <source>Encryption Key Failure</source>
        <translation>Titkosítási kulcs hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="34"/>
        <source>One or more files are corrupted</source>
        <translation>Egy vagy több fájl sérült</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="30"/>
        <source>Configuration Failure</source>
        <translation>Konfigurációs hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/ErrorMessages/ErrorMessages.qml" line="33"/>
        <source>Serial Number Failure</source>
        <translation>Sorozatszám hiba</translation>
    </message>
</context>
<context>
    <name>ErrorMultipleDataCarrier</name>
    <message>
        <location filename="../qml/content/errors/ErrorMultipleDataCarrier.qml" line="6"/>
        <source>Multiple Data Carrier Error</source>
        <translation>Többszörös adathordozó-hiba</translation>
    </message>
</context>
<context>
    <name>ErrorNTP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNTP.qml" line="6"/>
        <source>NTP Error</source>
        <translation>NTP-hiba</translation>
    </message>
</context>
<context>
    <name>ErrorNetworkDHCP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkDHCP.qml" line="6"/>
        <source>DHCP Error</source>
        <translation>DHCP-hiba</translation>
    </message>
</context>
<context>
    <name>ErrorNetworkIP</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkIP.qml" line="6"/>
        <source>Network IP Error</source>
        <translation>Hálózati IP-hiba</translation>
    </message>
</context>
<context>
    <name>ErrorNetworkWiFi</name>
    <message>
        <location filename="../qml/content/errors/ErrorNetworkWiFi.qml" line="6"/>
        <source>WiFi Error</source>
        <translation>WiFi hiba</translation>
    </message>
</context>
<context>
    <name>ErrorRFID</name>
    <message>
        <location filename="../qml/content/errors/ErrorRFID.qml" line="6"/>
        <source>RFID Error</source>
        <translation>RF-azonosító hiba</translation>
    </message>
</context>
<context>
    <name>ErrorSCard</name>
    <message>
        <location filename="../qml/content/errors/ErrorSCard.qml" line="6"/>
        <source>SmartCard Error. Please check card orientation. Chip facing away from you.</source>
        <translation>SmartCard hiba. Kérjük, ellenőrizze, merre néz a kártya. A chip Öntől messzebb van.</translation>
    </message>
</context>
<context>
    <name>ErrorSaveSettings</name>
    <message>
        <location filename="../qml/content/errors/ErrorSaveSettings.qml" line="6"/>
        <source>Save Settings Error</source>
        <translation>Beállítások mentése közbeni hiba</translation>
    </message>
</context>
<context>
    <name>ErrorTime</name>
    <message>
        <location filename="../qml/content/errors/ErrorTime.qml" line="6"/>
        <source>Manual Time Set Error</source>
        <translation>Kézi időbeállítási hiba</translation>
    </message>
</context>
<context>
    <name>ErrorUSBKey</name>
    <message>
        <location filename="../qml/content/errors/ErrorUSBKey.qml" line="6"/>
        <source>USB Key Error</source>
        <translation>USB-kulcs hiba</translation>
    </message>
</context>
<context>
    <name>EventDetails</name>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="12"/>
        <source>DETAILS</source>
        <translation>RÉSZLETEK</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="58"/>
        <source>License Plate:</source>
        <translation>Rendszám:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="90"/>
        <source>From:</source>
        <extracomment>Timespan</extracomment>
        <translation>Ettől:</translation>
    </message>
    <message>
        <location filename="../qml/content/driveroverview/events/EventDetails.qml" line="133"/>
        <source>Till:</source>
        <extracomment>Timespan</extracomment>
        <translation>Eddig:</translation>
    </message>
</context>
<context>
    <name>EventMessages</name>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="97"/>
        <source>No further details</source>
        <translation>Nincs további részlet</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="98"/>
        <source>Insertion of non-valid card</source>
        <translation>Érvénytelen kártya behelyezése</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="99"/>
        <source>Card conflict</source>
        <translation>Kártyaütközés</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="100"/>
        <source>Time overlap</source>
        <translation>Időátfedés</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="101"/>
        <source>Driving without an appropriate card</source>
        <translation>Megfelelő kártya nélküli vezetés</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="102"/>
        <source>Card insertion while driving</source>
        <translation>Kártya behelyezése vezetés közben</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="103"/>
        <source>Last card session not correctly closed</source>
        <translation>A legutóbbi kártyamunkamenet nem lett rendesen lezárva</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="104"/>
        <source>Over speeding</source>
        <translation>Gyorshajtás</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="105"/>
        <source>Power supply interruption</source>
        <translation>Tápellátás megszakítása</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="109"/>
        <source>Communication error with the remote communication facility</source>
        <translation>Kommunikációs hiba a távoli kommunikációs létesítménnyel</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="110"/>
        <source>Absence of position information from GNSS receiver</source>
        <translation>A GNSS-vevőről jövő pozícióra vonatkozó információ hiánya</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="111"/>
        <source>Communication error with the external GNSS facility</source>
        <translation>Kommunikációs hiba a belső GNSS-létesítménnyel</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="113"/>
        <source>Motion sensor authentication failure</source>
        <translation>Mozgásérzékelő hitelesítési hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="114"/>
        <source>Tachograph card authentication failure</source>
        <translation>Tachográf-kártya hitelesítési hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="115"/>
        <source>Unauthorised change of motion sensor</source>
        <translation>Mozgásérzékelő jogosulatlan cseréje</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="116"/>
        <source>Card data input integrity error</source>
        <translation>A kártya adatbeviteli integritás hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="117"/>
        <source>Stored user data integrity error</source>
        <translation>Tárolt felhasználói adatok integritási hibája</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="118"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="127"/>
        <source>Internal data transfer error</source>
        <translation>Belső adatátviteli hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="119"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="128"/>
        <source>Unauthorised case opening</source>
        <translation>Jogosulatlan burkolat bontás</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="120"/>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="129"/>
        <source>Hardware sabotage</source>
        <translation>Hardver szabotázs</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="121"/>
        <source>Tamper detection of GNSS</source>
        <translation>GNSS szabotázs észlelése</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="122"/>
        <source>External GNSS facility authentication failure</source>
        <translation>Külső GNSS hitelesítési hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="123"/>
        <source>External GNSS facility certificate expired</source>
        <translation>A külső GNSS tanúsítványa lejárt</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="125"/>
        <source>Authentication failure</source>
        <translation>Hitelesítési hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="126"/>
        <source>Stored data integrity error</source>
        <translation>A tárolt adatok integritásának hibája</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="131"/>
        <source>VU internal fault</source>
        <translation>JE belső hibája</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="132"/>
        <source>Printer fault</source>
        <translation>Nyomtató hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="133"/>
        <source>Display fault</source>
        <translation>Kijelző hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="134"/>
        <source>Downloading fault</source>
        <translation>Letöltési hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="135"/>
        <source>Sensor fault</source>
        <translation>Jeladó hiba</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="136"/>
        <source>Internal GNSS receiver</source>
        <translation>Belső GNSS vevő</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="137"/>
        <source>External GNSS facility</source>
        <translation>Külső GNSS eszköz</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="138"/>
        <source>Remote communication facility</source>
        <translation>Távoli kommunikációs lehetőség</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="139"/>
        <source>ITS interface</source>
        <translation>ITS interfész</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="106"/>
        <source>Motion data error</source>
        <translation>Mozgásra vonatkozó adatok hibája</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="107"/>
        <source>Vehicle motion conflict</source>
        <translation>Jármű mozgásával kapcsolatos konfliktus</translation>
    </message>
    <message>
        <source>Security breach attempt</source>
        <translation type="vanished">Biztonság feltörésének kísérlete</translation>
    </message>
    <message>
        <location filename="../qml/imports/EventMessages/EventMessages.qml" line="108"/>
        <source>Time conflict</source>
        <translation>Időütközés</translation>
    </message>
    <message>
        <source>Card</source>
        <translation type="vanished">Kártya</translation>
    </message>
    <message>
        <source>Recording equipment</source>
        <translation type="vanished">Felvevő berendezés</translation>
    </message>
</context>
<context>
    <name>EventsOfDayList</name>
    <message>
        <location filename="../qml/content/driveroverview/calendar/EventsOfDayList.qml" line="13"/>
        <source>DETAILS</source>
        <translation>RÉSZLETEK</translation>
    </message>
    <message>
        <source>Work</source>
        <translation type="vanished">Munka</translation>
    </message>
    <message>
        <source>Driving</source>
        <translation type="vanished">Vezetés</translation>
    </message>
    <message>
        <source>Available</source>
        <translation type="vanished">Elérhetőség</translation>
    </message>
</context>
<context>
    <name>Gateway</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/Gateway.qml" line="6"/>
        <source>DEFAULT GATEWAY</source>
        <translation>ALAPÉRTELMEZETT ÁTJÁRÓ</translation>
    </message>
</context>
<context>
    <name>Homescreen</name>
    <message>
        <source>HOME</source>
        <translation type="vanished">KEZDŐLAP</translation>
    </message>
    <message>
        <source>Proceed with factory reset?</source>
        <translation type="vanished">Folytatja a gyári visszaállítást?</translation>
    </message>
    <message>
        <source>Proceed with system update?</source>
        <translation type="vanished">Folytatja a rendszerfrissítéssel?</translation>
    </message>
    <message>
        <source>Transfer of system update to device in progress</source>
        <translation type="obsolete">A rendszerfrissítés átvitele az eszközre folyamatban</translation>
    </message>
    <message>
        <source>Installation of system update in progress</source>
        <translation type="obsolete">A rendszerfrissítés telepítése folyamatban</translation>
    </message>
    <message>
        <source>An error occured during update!</source>
        <translation type="vanished">Hiba történt a frissítés során!</translation>
    </message>
    <message>
        <source>USB Operation</source>
        <translation type="obsolete">Az USB működése</translation>
    </message>
    <message>
        <source>Your changes have been applied</source>
        <translation type="obsolete">Változtatások végrehajtva</translation>
    </message>
    <message>
        <source>System is going to reboot</source>
        <translation type="vanished">A rendszer újraindul</translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="52"/>
        <source>PIN correct.&lt;br&gt;Unlocking DLK.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="69"/>
        <source>INVALID PIN&lt;br&gt;Please try again.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/Homescreen.qml" line="91"/>
        <source>DOWNLOAD KEY REMOVED.</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>InfoLocalConfiguration</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoLocalConfiguration.qml" line="6"/>
        <source>Local Configuration Pending</source>
        <translation>A helyi konfiguráció függőben van</translation>
    </message>
</context>
<context>
    <name>InfoRemoteAccess</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoRemoteAccess.qml" line="6"/>
        <source>Remote Access</source>
        <translation>Távoli hozzáférés</translation>
    </message>
</context>
<context>
    <name>InfoUpdatePending</name>
    <message>
        <location filename="../qml/content/homescreen/info/InfoUpdatePending.qml" line="6"/>
        <source>Update Pending</source>
        <translation>A frissítés függőben van</translation>
    </message>
</context>
<context>
    <name>IpAddress</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/IpAddress.qml" line="6"/>
        <source>IP ADDRESS</source>
        <translation>IP-CÍM</translation>
    </message>
</context>
<context>
    <name>Keyboard</name>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="46"/>
        <source>q</source>
        <extracomment>Keyboard normal Key Q</extracomment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="107"/>
        <source>=/&lt;</source>
        <translation>=/&lt;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="145"/>
        <source>Q</source>
        <extracomment>Keyboard capsLock Key Q</extracomment>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="182"/>
        <source>@</source>
        <extracomment>Keyboard special Key Q</extracomment>
        <translation>@</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="183"/>
        <source>#</source>
        <extracomment>Keyboard special Key W</extracomment>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="184"/>
        <source>€</source>
        <extracomment>Keyboard special Key E</extracomment>
        <translation>€</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="185"/>
        <source>$</source>
        <extracomment>Keyboard special Key R</extracomment>
        <translation>$</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="186"/>
        <source>&amp;</source>
        <extracomment>Keyboard special Key T</extracomment>
        <translation>&amp;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="188"/>
        <source>+</source>
        <extracomment>Keyboard special Key U</extracomment>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="189"/>
        <source>*</source>
        <extracomment>Keyboard special Key I</extracomment>
        <translation>*</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="190"/>
        <source>/</source>
        <extracomment>Keyboard special Key O</extracomment>
        <translation>/</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="191"/>
        <source>=</source>
        <extracomment>Keyboard special Key P</extracomment>
        <translation>=</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="193"/>
        <source>%</source>
        <extracomment>Keyboard special Key A</extracomment>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="194"/>
        <source>&quot;</source>
        <extracomment>Keyboard special Key S</extracomment>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="195"/>
        <source>&apos;</source>
        <extracomment>Keyboard special Key D</extracomment>
        <translation>&apos;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="196"/>
        <source>:</source>
        <extracomment>Keyboard special Key F</extracomment>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="197"/>
        <source>;</source>
        <extracomment>Keyboard special Key G</extracomment>
        <translation>;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="198"/>
        <source>!</source>
        <extracomment>Keyboard special Key H</extracomment>
        <translation>!</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="199"/>
        <source>?</source>
        <extracomment>Keyboard special Key J</extracomment>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="200"/>
        <source>~</source>
        <extracomment>Keyboard special Key K</extracomment>
        <translation>~</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="201"/>
        <source>|</source>
        <extracomment>Keyboard special Key L</extracomment>
        <translation>|</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="202"/>
        <source>§</source>
        <extracomment>Keyboard special Key Ü</extracomment>
        <translation>§</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="204"/>
        <source>(</source>
        <extracomment>Keyboard special Key Y</extracomment>
        <translation>(</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="205"/>
        <source>)</source>
        <extracomment>Keyboard special Key X</extracomment>
        <translation>)</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="206"/>
        <source>{</source>
        <extracomment>Keyboard special Key C</extracomment>
        <translation>{</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="207"/>
        <source>}</source>
        <extracomment>Keyboard special Key V</extracomment>
        <translation>}</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="208"/>
        <source>[</source>
        <extracomment>Keyboard special Key B</extracomment>
        <translation>[</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="209"/>
        <source>]</source>
        <extracomment>Keyboard special Key N</extracomment>
        <translation>]</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="210"/>
        <source>&lt;</source>
        <extracomment>Keyboard special Key M</extracomment>
        <translation>&lt;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="211"/>
        <source>&gt;</source>
        <extracomment>Keyboard special Key Ö</extracomment>
        <translation>&gt;</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="212"/>
        <source>,</source>
        <extracomment>Keyboard special Key Ä</extracomment>
        <translation>,</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="213"/>
        <source>.</source>
        <extracomment>Keyboard special Key -</extracomment>
        <translation>.</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="47"/>
        <source>w</source>
        <extracomment>Keyboard normal Key W</extracomment>
        <translation>w</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="146"/>
        <source>W</source>
        <extracomment>Keyboard capsLock Key W</extracomment>
        <translation>W</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="48"/>
        <source>e</source>
        <extracomment>Keyboard normal Key E</extracomment>
        <translation>e</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="147"/>
        <source>E</source>
        <extracomment>Keyboard capsLock Key E</extracomment>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="49"/>
        <source>r</source>
        <extracomment>Keyboard normal Key R</extracomment>
        <translation>r</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="148"/>
        <source>R</source>
        <extracomment>Keyboard capsLock Key R</extracomment>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="50"/>
        <source>t</source>
        <extracomment>Keyboard normal Key T</extracomment>
        <translation>t</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="149"/>
        <source>T</source>
        <extracomment>Keyboard capsLock Key T</extracomment>
        <translation>T</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="51"/>
        <source>z</source>
        <extracomment>Keyboard normal Key Z</extracomment>
        <translation>z</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="150"/>
        <source>Z</source>
        <extracomment>Keyboard capsLock Key Z</extracomment>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="52"/>
        <source>u</source>
        <extracomment>Keyboard normal Key U</extracomment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="151"/>
        <source>U</source>
        <extracomment>Keyboard capsLock Key U</extracomment>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="53"/>
        <source>i</source>
        <extracomment>Keyboard normal Key I</extracomment>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="152"/>
        <source>I</source>
        <extracomment>Keyboard capsLock Key I</extracomment>
        <translation>I</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="54"/>
        <source>o</source>
        <extracomment>Keyboard normal Key O</extracomment>
        <translation>o</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="153"/>
        <source>O</source>
        <extracomment>Keyboard capsLock Key O</extracomment>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="55"/>
        <source>p</source>
        <extracomment>Keyboard normal Key P</extracomment>
        <translation>p</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="154"/>
        <source>P</source>
        <extracomment>Keyboard capsLock Key P</extracomment>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="57"/>
        <source>a</source>
        <extracomment>Keyboard normal Key A</extracomment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="156"/>
        <source>A</source>
        <extracomment>Keyboard capsLock Key A</extracomment>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="58"/>
        <source>s</source>
        <extracomment>Keyboard normal Key S</extracomment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="157"/>
        <source>S</source>
        <extracomment>Keyboard capsLock Key S</extracomment>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="59"/>
        <source>d</source>
        <extracomment>Keyboard normal Key D</extracomment>
        <translation>d</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="158"/>
        <source>D</source>
        <extracomment>Keyboard capsLock Key D</extracomment>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="60"/>
        <source>f</source>
        <extracomment>Keyboard normal Key F</extracomment>
        <translation>f</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="159"/>
        <source>F</source>
        <extracomment>Keyboard capsLock Key F</extracomment>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="61"/>
        <source>g</source>
        <extracomment>Keyboard normal Key G</extracomment>
        <translation>g</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="160"/>
        <source>G</source>
        <extracomment>Keyboard capsLock Key G</extracomment>
        <translation>G</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="62"/>
        <source>h</source>
        <extracomment>Keyboard normal Key H</extracomment>
        <translation>h</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="161"/>
        <source>H</source>
        <extracomment>Keyboard capsLock Key H</extracomment>
        <translation>H</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="63"/>
        <source>j</source>
        <extracomment>Keyboard normal Key J</extracomment>
        <translation>j</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="162"/>
        <source>J</source>
        <extracomment>Keyboard capsLock Key J</extracomment>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="64"/>
        <source>k</source>
        <extracomment>Keyboard normal Key K</extracomment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="163"/>
        <source>K</source>
        <extracomment>Keyboard capsLock Key K</extracomment>
        <translation>K</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="65"/>
        <source>l</source>
        <extracomment>Keyboard normal Key L</extracomment>
        <translation>l</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="164"/>
        <source>L</source>
        <extracomment>Keyboard capsLock Key L</extracomment>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="66"/>
        <source>ü</source>
        <extracomment>Keyboard normal Key Ü</extracomment>
        <translation>ü</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="165"/>
        <source>Ü</source>
        <extracomment>Keyboard capsLock Key Ü</extracomment>
        <translation>Ü</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="68"/>
        <source>y</source>
        <extracomment>Keyboard normal Key Y</extracomment>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="167"/>
        <source>Y</source>
        <extracomment>Keyboard capsLock Key Y</extracomment>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="69"/>
        <source>x</source>
        <extracomment>Keyboard normal Key X</extracomment>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="168"/>
        <source>X</source>
        <extracomment>Keyboard capsLock Key X</extracomment>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="70"/>
        <source>c</source>
        <extracomment>Keyboard normal Key C</extracomment>
        <translation>c</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="169"/>
        <source>C</source>
        <extracomment>Keyboard capsLock Key C</extracomment>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="71"/>
        <source>v</source>
        <extracomment>Keyboard normal Key V</extracomment>
        <translation>v</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="170"/>
        <source>V</source>
        <extracomment>Keyboard capsLock Key V</extracomment>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="72"/>
        <source>b</source>
        <extracomment>Keyboard normal Key B</extracomment>
        <translation>b</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="171"/>
        <source>B</source>
        <extracomment>Keyboard capsLock Key B</extracomment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="73"/>
        <source>n</source>
        <extracomment>Keyboard normal Key N</extracomment>
        <translation>n</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="172"/>
        <source>N</source>
        <extracomment>Keyboard capsLock Key N</extracomment>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="74"/>
        <source>m</source>
        <extracomment>Keyboard normal Key M</extracomment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="173"/>
        <source>M</source>
        <extracomment>Keyboard capsLock Key M</extracomment>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="75"/>
        <source>ö</source>
        <extracomment>Keyboard normal Key Ö</extracomment>
        <translation>ö</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="174"/>
        <source>Ö</source>
        <extracomment>Keyboard capsLock Key Ö</extracomment>
        <translation>Ö</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="76"/>
        <source>ä</source>
        <extracomment>Keyboard normal Key Ä</extracomment>
        <translation>ä</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="175"/>
        <source>Ä</source>
        <extracomment>Keyboard capsLock Key Ä</extracomment>
        <translation>Ä</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="77"/>
        <location filename="../qml/components/misc/Keyboard.qml" line="187"/>
        <source>-</source>
        <extracomment>Keyboard normal Key -
----------
Keyboard special Key Z</extracomment>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../qml/components/misc/Keyboard.qml" line="176"/>
        <source>_</source>
        <extracomment>Keyboard capsLock Key -</extracomment>
        <translation>_</translation>
    </message>
    <message>
        <source>/+=</source>
        <extracomment>Keyboard Button</extracomment>
        <translation type="vanished">/+=</translation>
    </message>
</context>
<context>
    <name>Licence</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="6"/>
        <source>LICENCES</source>
        <translation>LICENCE</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="13"/>
        <source>Package List</source>
        <translation>Csomaglista</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/Licence.qml" line="20"/>
        <source>More Information</source>
        <translation>További információ</translation>
    </message>
</context>
<context>
    <name>MainFooter</name>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="127"/>
        <source>Your changes have been applied</source>
        <translation>Változtatások végrehajtva</translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="162"/>
        <source>Reboot pending for changes to take effect</source>
        <translation>Indítsa újra a változtatások életbe lépéséhez</translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="316"/>
        <source>Network connection could not be established</source>
        <translation>A hálózati kapcsolatot nem lehet létrehozni</translation>
    </message>
    <message>
        <location filename="../qml/components/MainFooter.qml" line="321"/>
        <source>Network connection established</source>
        <translation>A hálózati kapcsolat létrejött</translation>
    </message>
</context>
<context>
    <name>Miscellaneous</name>
    <message>
        <source>Speaker Active</source>
        <translation type="vanished">Hangszóró aktív</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Miscellaneous.qml" line="13"/>
        <source>Administration Area</source>
        <translation>Adminisztrációs terület</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Miscellaneous.qml" line="20"/>
        <source>Licences</source>
        <translation>Licence</translation>
    </message>
</context>
<context>
    <name>MiscellaneousAdmin</name>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="27"/>
        <source>Speaker Active</source>
        <translation>Hangszóró aktív</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="41"/>
        <source>Communicator Busy</source>
        <translation>Kommunikátor foglalt</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/MiscellaneousAdmin.qml" line="47"/>
        <source>Licences</source>
        <translation>Licence</translation>
    </message>
</context>
<context>
    <name>MoreInformation</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="9"/>
        <source>MORE LICENCE INFORMATION</source>
        <translation>TOVÁBBI LICENCE INFORMÁCIÓ</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="22"/>
        <source>For more licence information please visit:</source>
        <translation>További információkért kérjük, látogasson el a következő webhelyre:</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/MoreInformation.qml" line="32"/>
        <source>https://www.smartterminal.vdo.com/</source>
        <translation>https://www.smartterminal.vdo.com/</translation>
    </message>
</context>
<context>
    <name>Nameserver</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/Nameserver.qml" line="6"/>
        <source>NAMESERVER</source>
        <translation>NAMESERVER</translation>
    </message>
</context>
<context>
    <name>Network</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="6"/>
        <source>NETWORK</source>
        <translation>HÁLÓZAT</translation>
    </message>
    <message>
        <source>Network Mode</source>
        <translation type="vanished">Hálózat-mód</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="26"/>
        <source>DHCP</source>
        <translation>DHCP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="27"/>
        <source>Disabled</source>
        <translation>Kikapcsolva</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="40"/>
        <source>IP Settings</source>
        <translation>IP-beállítások</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="46"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/Network.qml" line="52"/>
        <source>Dataport</source>
        <translation>Adatport</translation>
    </message>
</context>
<context>
    <name>NetworkSettings</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="6"/>
        <source>IP SETTINGS</source>
        <translation>IP-BEÁLLÍTÁSOK</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="31"/>
        <source>DHCP</source>
        <translation>DHCP</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="43"/>
        <source>IP Address</source>
        <translation>IP-cím</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="49"/>
        <source>Broadcast Address</source>
        <translation>Sugárzási cím</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="55"/>
        <source>Subnet Mask</source>
        <translation>Subnet maszk</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="61"/>
        <source>Default Gateway</source>
        <translation>Alapértelmezett átjáró</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/NetworkSettings.qml" line="67"/>
        <source>Nameserver</source>
        <translation>Nameserver</translation>
    </message>
</context>
<context>
    <name>NtpPortNumber</name>
    <message>
        <location filename="../qml/content/settings/datetime/ntp/NtpPortNumber.qml" line="10"/>
        <source>NTP PORTNUMBER</source>
        <translation>NTP PORTSZÁM</translation>
    </message>
</context>
<context>
    <name>NtpServer</name>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="9"/>
        <source>NTP SERVER</source>
        <translation>NTP-KISZOLGÁLÓ</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="28"/>
        <source>NTP Active</source>
        <translation>NTP aktív</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/datetime/NtpServer.qml" line="40"/>
        <source>NTP Servername</source>
        <translation>NTP kiszolgálónév</translation>
    </message>
    <message>
        <source>NTP Portnumber</source>
        <translation type="vanished">NTP portszém</translation>
    </message>
</context>
<context>
    <name>NtpServerName</name>
    <message>
        <location filename="../qml/content/settings/datetime/ntp/NtpServerName.qml" line="11"/>
        <source>NTP SERVERNAME</source>
        <translation>NTP KISZOLGÁLÓNÉV</translation>
    </message>
</context>
<context>
    <name>OperatingMode</name>
    <message>
        <source>Select Mode</source>
        <translation type="vanished">Mód kiválasztása</translation>
    </message>
    <message>
        <source>Serial</source>
        <translation type="vanished">Sorozatszám</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="44"/>
        <source>USB-Key</source>
        <translation>USB-kulcs</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="56"/>
        <source>USB-Cable</source>
        <translation>USB-kábel</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="68"/>
        <source>Network</source>
        <translation>Hálózat</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/OperatingMode.qml" line="80"/>
        <source>Network Settings</source>
        <translation>Hálózat beállítások</translation>
    </message>
    <message>
        <source>Standalone</source>
        <translation type="obsolete">Egyedülálló</translation>
    </message>
    <message>
        <source>USB</source>
        <translation type="vanished">USB</translation>
    </message>
</context>
<context>
    <name>PackageList</name>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/PackageList.qml" line="9"/>
        <source>PACKAGE LICENCES</source>
        <translation>CSOMAG LICENCE</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/miscellaneous/licence/PackageList.qml" line="25"/>
        <source>Loading package list, please wait.</source>
        <translation>Csomaglista betöltése, kérjük, várjon.</translation>
    </message>
</context>
<context>
    <name>ResetFrame</name>
    <message>
        <location filename="../qml/content/homescreen/ResetFrame.qml" line="69"/>
        <source>Proceed</source>
        <translation>Folytassa</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/ResetFrame.qml" line="106"/>
        <source>Cancel</source>
        <translation>Mégse</translation>
    </message>
</context>
<context>
    <name>RfidFrame</name>
    <message>
        <location filename="../qml/content/homescreen/RfidFrame.qml" line="23"/>
        <source>RFID TAG RECOGNIZED</source>
        <translation>RF-AZONOSÍTÓ CÍMKE FELISMERVE</translation>
    </message>
</context>
<context>
    <name>Screensaver</name>
    <message>
        <location filename="../qml/content/settings/Screensaver.qml" line="45"/>
        <source>Screensaver Active</source>
        <translation>Képernyővédő aktív</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Screensaver.qml" line="57"/>
        <source>Inactivity Timeout</source>
        <translation>Inaktivitási időtúllépés</translation>
    </message>
</context>
<context>
    <name>Select</name>
    <message>
        <source>SELECT</source>
        <translation type="vanished">KIVÁLASZT</translation>
    </message>
    <message>
        <source>Standalone</source>
        <translation type="vanished">Egyedülálló</translation>
    </message>
    <message>
        <source>USB</source>
        <translation type="vanished">USB</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="vanished">Hálózat</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../qml/content/Settings.qml" line="8"/>
        <source>INFORMATION</source>
        <translation>INFORMÁCIÓ</translation>
    </message>
    <message>
        <location filename="../qml/content/Settings.qml" line="13"/>
        <source>LANGUAGE</source>
        <translation>NYELV</translation>
    </message>
    <message>
        <location filename="../qml/content/Settings.qml" line="18"/>
        <source>MISCELLANEOUS</source>
        <translation>VEGYES</translation>
    </message>
</context>
<context>
    <name>SettingsAdmin</name>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="6"/>
        <source>INFORMATION</source>
        <translation>INFORMÁCIÓ</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="11"/>
        <source>LANGUAGE</source>
        <translation>NYELV</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="16"/>
        <source>MISCELLANEOUS</source>
        <translation>VEGYES</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="21"/>
        <source>DATE AND TIME</source>
        <translation>DÁTUM ÉS IDŐ</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="26"/>
        <source>SCREENSAVER</source>
        <translation>KÉPERNYŐVÉDŐ</translation>
    </message>
    <message>
        <location filename="../qml/content/SettingsAdmin.qml" line="31"/>
        <source>OPERATING MODE</source>
        <translation>MŰKÖDÉSI MÓD</translation>
    </message>
</context>
<context>
    <name>SubnetMask</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/settings/SubnetMask.qml" line="6"/>
        <source>SUBNET MASK</source>
        <translation>SUBNET MASZK</translation>
    </message>
</context>
<context>
    <name>SumOfDay</name>
    <message>
        <location filename="../qml/content/driveroverview/calendar/SumOfDay.qml" line="14"/>
        <source>EVENT DAY</source>
        <translation>ESEMÉNYNAP</translation>
    </message>
    <message>
        <source>Work</source>
        <translation type="vanished">Munka</translation>
    </message>
    <message>
        <source>Driving</source>
        <translation type="vanished">Vezetés</translation>
    </message>
    <message>
        <source>Available</source>
        <translation type="vanished">Elérhető</translation>
    </message>
    <message>
        <source>Rest</source>
        <translation type="vanished">Pihenés</translation>
    </message>
</context>
<context>
    <name>Systeminfo</name>
    <message>
        <source>USB</source>
        <translation type="vanished">USB</translation>
    </message>
    <message>
        <source>Serial</source>
        <translation type="vanished">Sorozatszám</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="21"/>
        <source>USB-Key</source>
        <translation>USB-kulcs</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="26"/>
        <source>USB-Cable</source>
        <translation>USB-kábel</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="31"/>
        <source>Network</source>
        <translation>Hálózat</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="35"/>
        <source>None</source>
        <translation>Egyik sem</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="44"/>
        <source>Version</source>
        <translation>Verzió</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="50"/>
        <source>S/N</source>
        <translation>S/N</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="56"/>
        <source>IP Address</source>
        <translation>IP-CÍM</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/Systeminfo.qml" line="62"/>
        <source>Operating Mode</source>
        <translation>Működési mód</translation>
    </message>
</context>
<context>
    <name>Time</name>
    <message>
        <location filename="../qml/content/settings/datetime/Time.qml" line="10"/>
        <source>TIME</source>
        <translation>IDŐ</translation>
    </message>
</context>
<context>
    <name>Timeout</name>
    <message>
        <location filename="../qml/content/settings/screensaver/Timeout.qml" line="10"/>
        <source>TIMEOUT</source>
        <translation>IDŐTÚLLÉPÉS</translation>
    </message>
</context>
<context>
    <name>UpdateErrorFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UpdateErrorFrame.qml" line="66"/>
        <source>Proceed</source>
        <translation>Folytassa</translation>
    </message>
</context>
<context>
    <name>UpdateFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UpdateFrame.qml" line="75"/>
        <source>Proceed</source>
        <translation>Folytassa</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/UpdateFrame.qml" line="105"/>
        <source>Cancel</source>
        <translation>Mégse</translation>
    </message>
</context>
<context>
    <name>UsbConfirmEndFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UsbConfirmEndFrame.qml" line="29"/>
        <source>USB commands have been carried out</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/UsbConfirmEndFrame.qml" line="45"/>
        <source>OK</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>UsbConfirmFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UsbConfirmFrame.qml" line="31"/>
        <source>New USB commands</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/UsbConfirmFrame.qml" line="66"/>
        <source>Proceed</source>
        <translation>Folytassa</translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/UsbConfirmFrame.qml" line="84"/>
        <source>Abort</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>UsbNeedsClearingFrame</name>
    <message>
        <location filename="../qml/content/homescreen/UsbNeedsClearingFrame.qml" line="29"/>
        <source>USB stick carries data for this terminal and needs clearing by TerminalTools before it can be used again</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/content/homescreen/UsbNeedsClearingFrame.qml" line="46"/>
        <source>OK</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>UsbOverview</name>
    <message>
        <location filename="../qml/content/UsbOverview.qml" line="12"/>
        <source>DRIVER</source>
        <translation>JÁRMŰVEZETŐ</translation>
    </message>
    <message>
        <location filename="../qml/content/UsbOverview.qml" line="18"/>
        <source>VEHICLE INFORMATION</source>
        <translation>JÁRMŰ INFORMÁCIÓ</translation>
    </message>
</context>
<context>
    <name>VehicleInformation</name>
    <message>
        <location filename="../qml/content/usboverview/vehicleselect/VehicleInformation.qml" line="51"/>
        <source>Start</source>
        <translation>Indítás</translation>
    </message>
    <message>
        <location filename="../qml/content/usboverview/vehicleselect/VehicleInformation.qml" line="82"/>
        <source>End</source>
        <translation>Vége</translation>
    </message>
</context>
<context>
    <name>WiFiPassword</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/wifi/WiFiPassword.qml" line="11"/>
        <source>WIFI PASSWORD</source>
        <translation>WIFI JELSZÓ</translation>
    </message>
</context>
<context>
    <name>WiFiSSID</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/wifi/WiFiSSID.qml" line="10"/>
        <source>WIFI SSID</source>
        <translation>WIFI SSID</translation>
    </message>
</context>
<context>
    <name>WiFiSettings</name>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="6"/>
        <source>WIFI SETTINGS</source>
        <translation>WIFI BEÁLLÍTÁSOK</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="25"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="38"/>
        <source>WiFi SSID</source>
        <translation>WiFi SSID</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="44"/>
        <source>WiFi Password</source>
        <translation>Wifi jelszó</translation>
    </message>
    <message>
        <location filename="../qml/content/settings/operatingmode/network/WiFiSettings.qml" line="50"/>
        <source>WiFi Available Networks</source>
        <translation>Elérhető WiFi-hálózatok</translation>
    </message>
</context>
<context>
    <name>Zone</name>
    <message>
        <location filename="../qml/content/settings/datetime/Zone.qml" line="9"/>
        <source>TIMEZONE</source>
        <translation>IDŐZÓNA</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>VDO Terminal v4</source>
        <translation type="vanished">VDO terminál v4</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="77"/>
        <source>VDO SmartTerminal</source>
        <translation>VDO SmartTerminal</translation>
    </message>
</context>
</TS>
